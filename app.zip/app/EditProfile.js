import React, { useEffect, useState } from 'react';
import {
    View, Text, TextInput, Alert, ScrollView,
    KeyboardAvoidingView, Platform, StyleSheet, TouchableOpacity, Image, StatusBar
} from 'react-native';
import { useLocalSearchParams, useNavigation } from 'expo-router';
import Footer from './Footer';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from './Themecontext';

export default function EditProfile() {
    const navigation = useNavigation();
    const { userId } = useLocalSearchParams();
    const { theme, isDark } = useTheme();
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [focusedField, setFocusedField] = useState(null);

    const API_BASE_URL = 'https://kisan-seva-user.onrender.com';

    useEffect(() => { if (userId) fetchUserDetails(); }, [userId]);

    const fetchUserDetails = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/users/${userId}`);
            const result = await response.json();
            if (result.status_code === 200 && result.data) setUserData(result.data);
            else setUserData(null);
        } catch { Alert.alert('Error', 'Failed to load user data.'); }
        finally { setLoading(false); }
    };

    const handleUpdate = async () => {
        try {
            const payload = {
                name: userData.name, email: userData.email,
                password: userData.password, number: userData.number,
                profileImage: userData.profileImage, backImage: userData.backImage,
            };
            const response = await fetch(`${API_BASE_URL}/api/users/update/${userId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const text = await response.text();
            const result = JSON.parse(text);
            if (result.status_code === 200) {
                Alert.alert('Success', 'Profile updated successfully.');
                navigation.goBack();
            } else {
                Alert.alert('Error', text);
            }
        } catch (error) { Alert.alert('Error', error.message); }
    };

    if (loading) return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.bg }}>
            <Text style={{ color: theme.textSecondary }}>Loading…</Text>
        </View>
    );
    if (!userData) return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.bg }}>
            <Text style={{ color: theme.danger }}>User data not found</Text>
        </View>
    );

    const fields = [
        { key: 'name',     label: 'Full Name',     icon: 'person-outline',      keyboard: 'default',       secure: false },
        { key: 'email',    label: 'Email Address',  icon: 'mail-outline',        keyboard: 'email-address', secure: false },
        { key: 'password', label: 'Password',       icon: 'lock-closed-outline', keyboard: 'default',       secure: true  },
        { key: 'number',   label: 'Phone Number',   icon: 'call-outline',        keyboard: 'phone-pad',     secure: false },
    ];

    return (
        <View style={[styles.root, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} />

            {isDark && (
                <>
                    <View style={styles.orb1} />
                    <View style={styles.orb2} />
                </>
            )}

            <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={80}>
                <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>

                    {/* Header */}
                    <View style={[styles.header, { backgroundColor: theme.headerBg, borderBottomColor: theme.headerBorder }]}>
                        <TouchableOpacity
                            onPress={() => navigation.goBack()}
                            style={[styles.backBtn, { backgroundColor: theme.backBtnBg }]}
                        >
                            <Ionicons name="arrow-back" size={20} color={theme.backBtnIcon} />
                        </TouchableOpacity>
                        <Text style={[styles.headerTitle, { color: theme.textPrimary }]}>Edit Profile</Text>
                        <View style={{ width: 40 }} />
                    </View>

                    {/* Profile card */}
                    <View style={[styles.profileCard, {
                        backgroundColor: theme.cardSolid,
                        borderColor: theme.cardBorder,
                        borderWidth: 1,
                    }]}>
                        {userData.backImage ? (
                            <Image source={{ uri: `${API_BASE_URL}/uploads/${userData.backImage}` }} style={styles.coverImage} />
                        ) : (
                            <View style={[styles.coverPlaceholder, { backgroundColor: isDark ? '#0d1f3a' : '#1a3d1a' }]}>
                                <View style={[styles.coverDeco, { backgroundColor: isDark ? 'rgba(46,196,130,0.12)' : 'rgba(46,196,130,0.18)' }]} />
                                <View style={[styles.coverDeco2, { backgroundColor: isDark ? 'rgba(56,130,246,0.07)' : 'rgba(22,163,74,0.08)' }]} />
                            </View>
                        )}

                        <View style={[styles.avatarWrap, {
                            borderColor: isDark ? 'rgba(46,196,130,0.4)' : '#fff',
                            backgroundColor: theme.inputBg,
                        }]}>
                            {userData.profileImage ? (
                                <Image source={{ uri: `${API_BASE_URL}/uploads/${userData.profileImage}` }} style={styles.avatar} />
                            ) : (
                                <View style={[styles.avatarPlaceholder, { backgroundColor: theme.surface }]}>
                                    <Ionicons name="person" size={36} color={theme.textMuted} />
                                </View>
                            )}
                        </View>

                        <Text style={[styles.profileName, { color: theme.textPrimary }]}>{userData.name || 'Your Name'}</Text>
                        <Text style={[styles.profileHandle, { color: theme.textMuted }]}>@{(userData.name || 'user').toLowerCase().replace(' ', '')}</Text>
                    </View>

                    {/* Form */}
                    <View style={[styles.formCard, {
                        backgroundColor: theme.cardSolid,
                        borderColor: theme.cardBorder,
                        borderWidth: 1,
                    }]}>
                        <Text style={[styles.formTitle, { color: theme.textPrimary }]}>Personal Information</Text>

                        {fields.map(f => (
                            <View key={f.key} style={{ marginBottom: 14 }}>
                                <Text style={[styles.label, { color: theme.textSecondary }]}>{f.label}</Text>
                                <View style={[
                                    styles.inputRow,
                                    {
                                        backgroundColor: theme.inputBg,
                                        borderColor: focusedField === f.key ? theme.inputFocusBorder : theme.inputBorder,
                                    }
                                ]}>
                                    <Ionicons name={f.icon} size={18} color={focusedField === f.key ? theme.accent : theme.iconColor} />
                                    <TextInput
                                        style={[styles.input, { color: theme.inputText }]}
                                        placeholder={f.label}
                                        placeholderTextColor={theme.placeholder}
                                        value={userData[f.key] || ''}
                                        onChangeText={(text) => setUserData({ ...userData, [f.key]: text })}
                                        keyboardType={f.keyboard}
                                        secureTextEntry={f.secure}
                                        onFocus={() => setFocusedField(f.key)}
                                        onBlur={() => setFocusedField(null)}
                                    />
                                </View>
                            </View>
                        ))}

                        <TouchableOpacity
                            style={[styles.updateButton, {
                                backgroundColor: theme.accent,
                                shadowColor: theme.accent,
                            }]}
                            onPress={handleUpdate}
                            activeOpacity={0.85}
                        >
                            <Ionicons name="checkmark-circle" size={20} color={theme.accentDark} />
                            <Text style={[styles.updateText, { color: theme.accentDark }]}>Update Profile</Text>
                        </TouchableOpacity>
                    </View>

                </ScrollView>
            </KeyboardAvoidingView>

            <Footer />
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1 },
    orb1: { position: 'absolute', width: 250, height: 250, borderRadius: 125, backgroundColor: 'rgba(46,196,130,0.06)', top: -60, right: -60 },
    orb2: { position: 'absolute', width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(56,130,246,0.04)', top: 300, left: -50 },

    scrollContainer: { paddingBottom: 120 },

    header: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingTop: 54, paddingBottom: 14, paddingHorizontal: 16, borderBottomWidth: 1,
    },
    backBtn: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
    headerTitle: { fontSize: 18, fontWeight: '800' },

    profileCard: {
        marginTop: 16, marginHorizontal: 16, borderRadius: 24,
        overflow: 'hidden', alignItems: 'center', paddingBottom: 20,
        shadowColor: '#000', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.15, shadowRadius: 14, elevation: 8,
    },
    coverImage: { width: '100%', height: 130 },
    coverPlaceholder: { width: '100%', height: 130, overflow: 'hidden' },
    coverDeco: { position: 'absolute', width: 250, height: 250, borderRadius: 125, top: -80, right: -60 },
    coverDeco2: { position: 'absolute', width: 160, height: 160, borderRadius: 80, bottom: -40, left: -30 },

    avatarWrap: {
        marginTop: -44, width: 88, height: 88, borderRadius: 44,
        borderWidth: 3, overflow: 'hidden',
        shadowColor: '#2ec482', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8,
    },
    avatar: { width: '100%', height: '100%' },
    avatarPlaceholder: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
    profileName: { marginTop: 10, fontSize: 18, fontWeight: '800' },
    profileHandle: { marginTop: 2, fontSize: 13 },

    formCard: {
        marginTop: 16, marginHorizontal: 16, borderRadius: 24, padding: 20,
        shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 12, elevation: 6,
    },
    formTitle: { fontSize: 15, fontWeight: '800', marginBottom: 18 },
    label: { fontSize: 12, fontWeight: '600', marginBottom: 6, marginLeft: 2 },

    inputRow: {
        flexDirection: 'row', alignItems: 'center', gap: 10,
        borderRadius: 14, borderWidth: 1.5,
        paddingHorizontal: 14, height: 50,
    },
    input: { flex: 1, fontSize: 14, fontWeight: '500' },

    updateButton: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        gap: 8, height: 52, borderRadius: 16, marginTop: 4,
        shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.4, shadowRadius: 14, elevation: 10,
    },
    updateText: { fontSize: 15, fontWeight: '800', letterSpacing: 0.3 },
});