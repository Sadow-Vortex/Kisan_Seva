import React, { useEffect, useLayoutEffect, useState } from "react";
import {
    View, Image, FlatList, StyleSheet, Dimensions, ActivityIndicator,
    Text, TouchableOpacity, TextInput, ImageBackground, StatusBar
} from "react-native";
import { useLocalSearchParams, useNavigation } from "expo-router";
import Footer from "./Footer";
import { useTheme } from "./Themecontext";

const { width, height } = Dimensions.get("window");
const IMAGE_WIDTH = width / 3 - 20;

export default function SubCategory() {
    const navigation = useNavigation();
    const { categoryId } = useLocalSearchParams();
    const { theme, isDark } = useTheme();
    const [subCategory, setSubCategory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [categoryImage, setCategoryImage] = useState(null);
    const [categoryName, setCategoryName] = useState("Sub Categories");
    const [searchText, setSearchText] = useState("");
    const [filteredSubCategory, setFilteredSubCategory] = useState([]);

    const url = `https://kisan-seva-subcategory.onrender.com`;

    useLayoutEffect(() => { navigation.setOptions({ headerShown: false }); }, [navigation]);

    const fetchSubCategory = async () => {
        try {
            const response = await fetch(`${url}/subcategory/by-category/${categoryId}`);
            const data = await response.json();
            const subcategoryArray = Array.isArray(data?.data) ? data.data : [];
            setSubCategory(subcategoryArray);
            setFilteredSubCategory(subcategoryArray);
        } catch (error) { console.error(error); }
        finally { setLoading(false); }
    };

    const handleSearch = (text) => {
        setSearchText(text);
        if (!text.trim()) { setFilteredSubCategory(subCategory); return; }
        const filtered = subCategory.filter(item =>
            item.subCategoryName?.toLowerCase().includes(text.toLowerCase())
        );
        setFilteredSubCategory(filtered);
    };

    useEffect(() => { if (categoryId) fetchSubCategory(); }, [categoryId]);

    useEffect(() => {
        if (!categoryId) return;
        fetch(`${url}/category`)
            .then(res => res.json())
            .then(json => {
                const list = Array.isArray(json?.data) ? json.data : [];
                const current = list.find(c => String(c.categoryId) === String(categoryId));
                if (current) {
                    setCategoryImage(current.imageLink || null);
                    setCategoryName(current.categoryName || "Sub Categories");
                }
            })
            .catch(err => console.log("category image load error", err));
    }, [categoryId]);

    const renderItem = ({ item }) => (
        <TouchableOpacity
            style={[styles.card, {
                backgroundColor: theme.cardSolid,
                borderColor: theme.cardBorder,
                borderWidth: 1,
            }]}
            onPress={() => navigation.navigate("AdsBySubCategory", { subCategoryId: item.subCategoryId })}
        >
            <Image source={{ uri: item.subCategoryImageLink }} style={styles.image} />
            <View style={[styles.cardOverlay, { backgroundColor: 'rgba(46,196,130,0.05)' }]} />
            <Text style={[styles.cardTitle, { color: theme.textPrimary }]}>{item.subCategoryName}</Text>
        </TouchableOpacity>
    );

    if (loading) {
        return (
            <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', backgroundColor: theme.bg }}>
                <ActivityIndicator size="large" color={theme.accent} />
            </View>
        );
    }

    return (
        <View style={[styles.root, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} />

            {isDark && (
                <>
                    <View style={styles.orb1} />
                    <View style={styles.orb2} />
                </>
            )}

            {/* Banner */}
            <ImageBackground
                source={categoryImage ? { uri: categoryImage } : require('../assets/images/farm.jpg')}
                style={styles.banner}
                imageStyle={styles.bannerImage}
            >
                <View style={styles.bannerOverlay}>
                    <Text style={styles.bannerTitle}>{categoryName}</Text>
                    <Text style={styles.bannerSub}>Select your favourites</Text>
                </View>
            </ImageBackground>

            {/* Search */}
            <View style={[styles.searchWrapper, {
                backgroundColor: theme.cardSolid,
                borderColor: theme.cardBorder,
                borderWidth: 1,
            }]}>
                <Text style={{ fontSize: 16, marginRight: 8 }}>🔍</Text>
                <TextInput
                    placeholder="Search sub categories"
                    placeholderTextColor={theme.placeholder}
                    style={[styles.searchInput, { color: theme.inputText }]}
                    value={searchText}
                    onChangeText={handleSearch}
                />
            </View>

            {/* Section header */}
            <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: theme.textPrimary }]}>Browse Subcategories</Text>
                <View style={styles.sectionLineRow}>
                    <View style={[styles.sectionLine, { backgroundColor: theme.divider }]} />
                    <View style={[styles.sectionDot, { backgroundColor: theme.accent }]} />
                    <View style={[styles.sectionLine, { backgroundColor: theme.divider }]} />
                </View>
                <Text style={[styles.sectionSub, { color: theme.textSecondary }]}>Choose the type you want</Text>
            </View>

            {filteredSubCategory.length === 0 ? (
                <View style={styles.emptyContainer}>
                    <Text style={{ fontSize: 40 }}>🌿</Text>
                    <Text style={[styles.emptyText, { color: theme.textSecondary }]}>No sub categories found</Text>
                </View>
            ) : (
                <FlatList
                    data={filteredSubCategory}
                    keyExtractor={(item, index) => item?.subCategoryId ? item.subCategoryId.toString() : index.toString()}
                    renderItem={renderItem}
                    numColumns={3}
                    contentContainerStyle={styles.container}
                />
            )}

            <Footer />
        </View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1 },

    orb1: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(46,196,130,0.06)', top: height * 0.3, right: -60, zIndex: 0 },
    orb2: { position: 'absolute', width: 150, height: 150, borderRadius: 75, backgroundColor: 'rgba(56,130,246,0.04)', bottom: 100, left: -40, zIndex: 0 },

    banner: { height: height / 4, width: "100%", justifyContent: "flex-end" },
    bannerImage: { borderBottomLeftRadius: 26, borderBottomRightRadius: 26 },
    bannerOverlay: {
        padding: 18,
        backgroundColor: "rgba(0,0,0,0.4)",
        borderBottomLeftRadius: 26, borderBottomRightRadius: 26,
    },
    bannerTitle: { fontSize: 26, fontWeight: "800", color: "#ffffff" },
    bannerSub: { marginTop: 4, fontSize: 14, color: "rgba(255,255,255,0.85)", fontWeight: "600" },

    searchWrapper: {
        flexDirection: 'row', alignItems: 'center',
        marginTop: 12, marginHorizontal: 16,
        borderRadius: 20, paddingHorizontal: 16, height: 48,
        shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 10, elevation: 6,
    },
    searchInput: { flex: 1, fontSize: 14, fontWeight: '500' },

    sectionHeader: { marginTop: 18, marginBottom: 14, alignItems: "center" },
    sectionTitle: { fontSize: 20, fontWeight: "800" },
    sectionLineRow: { flexDirection: "row", alignItems: 'center', justifyContent: "center", width: "70%", marginVertical: 8, gap: 8 },
    sectionLine: { flex: 1, height: 1 },
    sectionDot: { width: 6, height: 6, borderRadius: 3 },
    sectionSub: { fontSize: 13 },

    container: { paddingHorizontal: 10, paddingBottom: 90 },

    card: {
        width: IMAGE_WIDTH, margin: 6, borderRadius: 18, overflow: "hidden",
        shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 8, elevation: 6,
    },
    image: { width: "100%", height: 110 },
    cardOverlay: { ...StyleSheet.absoluteFillObject, height: 110 },
    cardTitle: { paddingVertical: 10, textAlign: "center", fontSize: 13, fontWeight: "700" },

    emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
    emptyText: { fontSize: 14, fontWeight: '500' },
});