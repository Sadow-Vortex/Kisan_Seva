import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ThemeContext = createContext();

export const DARK = {
    bg: '#050e1a',
    bgLayer: '#0d1f3a',
    card: 'rgba(255,255,255,0.06)',
    cardSolid: '#111f35',
    cardBorder: 'rgba(255,255,255,0.11)',
    surface: '#111f35',
    surfaceElevated: '#162840',
    headerBg: '#0d1f3a',
    headerBorder: 'rgba(255,255,255,0.08)',

    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.55)',
    textMuted: 'rgba(255,255,255,0.3)',

    accent: '#2ec482',
    accentGlow: 'rgba(46,196,130,0.15)',
    accentBorder: 'rgba(46,196,130,0.4)',
    accentText: '#7eeab4',
    accentDark: '#0a1628',

    inputBg: 'rgba(255,255,255,0.07)',
    inputBorder: 'rgba(255,255,255,0.1)',
    inputFocusBg: 'rgba(46,196,130,0.05)',
    inputFocusBorder: 'rgba(46,196,130,0.55)',
    inputText: '#ffffff',
    placeholder: 'rgba(255,255,255,0.3)',

    statusBar: 'light-content',
    iconColor: 'rgba(255,255,255,0.5)',
    iconActive: '#2ec482',
    backBtnBg: 'rgba(255,255,255,0.08)',
    backBtnIcon: '#ffffff',

    divider: 'rgba(255,255,255,0.08)',

    badgeBg: 'rgba(46,196,130,0.15)',
    badgeText: '#7eeab4',

    statBg: 'rgba(255,255,255,0.06)',

    danger: '#ef4444',
    dangerBg: 'rgba(239,68,68,0.12)',
    dangerText: '#fca5a5',
};

export const LIGHT = {
    bg: '#f5ede4',
    bgLayer: '#ffffff',
    card: '#ffffff',
    cardSolid: '#ffffff',
    cardBorder: 'rgba(0,0,0,0.06)',
    surface: '#ffffff',
    surfaceElevated: '#f9fafb',
    headerBg: '#ffffff',
    headerBorder: '#e5f0e5',

    textPrimary: '#111827',
    textSecondary: '#6b7280',
    textMuted: '#9ca3af',

    accent: '#16a34a',
    accentGlow: 'rgba(22,163,74,0.1)',
    accentBorder: 'rgba(22,163,74,0.35)',
    accentText: '#16a34a',
    accentDark: '#ffffff',

    inputBg: '#f9fafb',
    inputBorder: '#e5e7eb',
    inputFocusBg: '#f0fdf4',
    inputFocusBorder: '#16a34a',
    inputText: '#111827',
    placeholder: '#9ca3af',

    statusBar: 'dark-content',
    iconColor: '#6b7280',
    iconActive: '#16a34a',
    backBtnBg: '#f0f7f0',
    backBtnIcon: '#1a2e1a',

    divider: '#f3f4f6',

    badgeBg: '#f0fdf4',
    badgeText: '#16a34a',

    statBg: '#f9fafb',

    danger: '#dc2626',
    dangerBg: 'rgba(220,38,38,0.08)',
    dangerText: '#dc2626',
};

export const ThemeProvider = ({ children }) => {
    const [isDark, setIsDark] = useState(true);

    useEffect(() => {
        AsyncStorage.getItem('appTheme').then(val => {
            if (val !== null) setIsDark(val === 'dark');
        });
    }, []);

    const toggleTheme = async () => {
        const next = !isDark;
        setIsDark(next);
        await AsyncStorage.setItem('appTheme', next ? 'dark' : 'light');
    };

    return (
        <ThemeContext.Provider value={{ theme: isDark ? DARK : LIGHT, isDark, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

export const useTheme = () => useContext(ThemeContext);