import React, { useEffect, useState, useLayoutEffect, useRef } from "react";
import {
    View, Image, FlatList, StyleSheet, Dimensions, ActivityIndicator,
    Text, TouchableOpacity, Alert, TextInput, Animated, StatusBar,
} from "react-native";
import { useNavigation, router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import Footer from "./Footer";
import * as Font from "expo-font";
import { useTheme } from "./Themecontext";

const { width, height } = Dimensions.get("window");

function extractArray(json) {
    if (!json) return [];
    if (Array.isArray(json)) return json;
    if (Array.isArray(json.data)) return json.data;
    if (json.data && typeof json.data === "object") return [json.data];
    if (Array.isArray(json.categories)) return json.categories;
    if (Array.isArray(json.subcategories)) return json.subcategories;
    if (Array.isArray(json.results)) return json.results;
    return [];
}

const WEATHER_THEMES = {
    rain:    { colors: ["#1e3a5f", "#2d6a9f"], emoji: "🌧️" },
    drizzle: { colors: ["#2c4a6e", "#3a7abf"], emoji: "🌦️" },
    snow:    { colors: ["#3a4f6b", "#6a8faf"], emoji: "❄️" },
    cloud:   { colors: ["#3d4f5c", "#6b8294"], emoji: "☁️" },
    clear:   { colors: ["#c05621", "#e07b39"], emoji: "☀️" },
    default: { colors: ["#0d2d4f", "#1a4a7a"], emoji: "🌤️" },
};

function getWeatherTheme(weather) {
    if (!weather?.weather?.[0]) return WEATHER_THEMES.default;
    const m = weather.weather[0].main.toLowerCase();
    if (m.includes("rain"))    return WEATHER_THEMES.rain;
    if (m.includes("drizzle")) return WEATHER_THEMES.drizzle;
    if (m.includes("snow"))    return WEATHER_THEMES.snow;
    if (m.includes("cloud"))   return WEATHER_THEMES.cloud;
    if (m.includes("clear"))   return WEATHER_THEMES.clear;
    return WEATHER_THEMES.default;
}

export default function HomeScreen() {
    const navigation = useNavigation();
    const { theme, isDark } = useTheme();

    const [categories,     setCategories]    = useState([]);
    const [loading,        setLoading]       = useState(true);
    const [searchText,     setSearchText]    = useState("");
    const [suggestions,    setSuggestions]   = useState([]);
    const [showSuggestion, setShowSuggestion]= useState(false);
    const [searching,      setSearching]     = useState(false);
    const [weather,        setWeather]       = useState(null);
    const [weatherLoading, setWeatherLoading]= useState(true);
    const [fontsLoaded,    setFontsLoaded]   = useState(false);

    const searchFocusAnim = useRef(new Animated.Value(0)).current;
    const suggestionAnim  = useRef(new Animated.Value(0)).current;
    const headerAnim      = useRef(new Animated.Value(0)).current;

    const url = "https://kisan-seva-subcategory.onrender.com";

    useEffect(() => {
        Font.loadAsync({
            PoppinsSemi:    require("../assets/fonts/Poppins-SemiBold.ttf"),
            PoppinsRegular: require("../assets/fonts/Poppins-Regular.ttf"),
        }).then(() => setFontsLoaded(true));
    }, []);

    useLayoutEffect(() => { navigation.setOptions({ headerShown: false }); }, [navigation]);

    useEffect(() => {
        fetchCategories();
        fetchWeather();
        Animated.spring(headerAnim, { toValue: 1, tension: 40, friction: 8, useNativeDriver: true }).start();
    }, []);

    useEffect(() => {
        Animated.timing(suggestionAnim, {
            toValue: showSuggestion ? 1 : 0,
            duration: 200, useNativeDriver: true,
        }).start();
    }, [showSuggestion]);

    const fetchCategories = async () => {
        try {
            const res  = await fetch(`${url}/category`);
            const json = await res.json();
            setCategories(extractArray(json));
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const fetchWeather = async () => {
        try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== "granted") { setWeatherLoading(false); return; }
            const enabled = await Location.hasServicesEnabledAsync();
            if (!enabled) { setWeatherLoading(false); return; }
            const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
            const res = await fetch(
                `https://api.openweathermap.org/data/2.5/weather?lat=${loc.coords.latitude}&lon=${loc.coords.longitude}&appid=32bea71aad47a04557f738d027a4c1de&units=metric`
            );
            setWeather(await res.json());
        } catch (e) { console.log("Weather error:", e); }
        finally { setWeatherLoading(false); }
    };

    const handleSearchInput = async (text) => {
        setSearchText(text);
        if (!text || text.trim().length < 1) {
            setSuggestions([]); setShowSuggestion(false); return;
        }
        setSearching(true);
        try {
            const encoded = encodeURIComponent(text.trim());
            const [catRes, subRes] = await Promise.allSettled([
                fetch(`${url}/category/by-name/${encoded}`).then(r => r.json()),
                fetch(`${url}/subcategory/by-name/${encoded}`).then(r => r.json()),
            ]);
            const catList = catRes.status === "fulfilled" ? extractArray(catRes.value) : [];
            const subList = subRes.status === "fulfilled" ? extractArray(subRes.value) : [];
            const merged = [
                ...catList.map(c => ({ type: "category",    id: c.categoryId    ?? c.id ?? c._id, name: c.categoryName    ?? c.name ?? c.title ?? "" })),
                ...subList.map(s => ({ type: "subcategory", id: s.subCategoryId ?? s.id ?? s._id, name: s.subCategoryName ?? s.name ?? s.title ?? "" })),
            ].filter(item => item.name);
            setSuggestions(merged);
            setShowSuggestion(merged.length > 0);
        } catch (e) { console.log(e); }
        finally { setSearching(false); }
    };

    const handleSuggestionPress = (item) => {
        setShowSuggestion(false); setSearchText("");
        if (item.type === "category") {
            router.push({ pathname: "/SubCategory",      params: { categoryId:    item.id } });
        } else {
            router.push({ pathname: "/AdsBySubCategory", params: { subCategoryId: item.id } });
        }
    };

    const handleSearchFocus = (focused) => {
        Animated.spring(searchFocusAnim, { toValue: focused ? 1 : 0, useNativeDriver: false }).start();
    };

    if (!fontsLoaded || loading) {
        return (
            <View style={[styles.loadingScreen, { backgroundColor: theme.bg }]}>
                <ActivityIndicator size="large" color={theme.accent} />
                <Text style={[styles.loadingText, { color: theme.textSecondary }]}>Loading Kisan Seva…</Text>
            </View>
        );
    }

    const wTheme = getWeatherTheme(weather);

    return (
        <View style={[styles.root, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} backgroundColor={theme.bg} />

            {/* Dark mode background orbs */}
            {isDark && (
                <>
                    <View style={styles.bgOrb1} />
                    <View style={styles.bgOrb2} />
                </>
            )}

            <FlatList
                data={categories}
                keyExtractor={(item) => item.categoryId?.toString() ?? Math.random().toString()}
                numColumns={3}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                ListHeaderComponent={
                    <>
                        {/* ── Top header bar ── */}
                        <Animated.View style={[styles.topBar, {
                            opacity: headerAnim,
                            transform: [{ translateY: headerAnim.interpolate({ inputRange: [0,1], outputRange: [-20, 0] }) }],
                        }]}>
                            <View>
                                <Text style={[styles.greeting, { color: theme.textMuted }]}>Good morning 🌿</Text>
                                <Text style={[styles.appName, { color: theme.textPrimary }]}>Kisan Seva</Text>
                            </View>
                            <TouchableOpacity
                                style={[styles.profileBtn, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}
                                onPress={() => router.push('/UserProfile')}
                            >
                                <Ionicons name="person-circle" size={26} color={theme.accent} />
                            </TouchableOpacity>
                        </Animated.View>

                        {/* ── Weather card ── */}
                        <View style={styles.weatherSection}>
                            {weatherLoading ? (
                                <View style={[styles.weatherCard, { backgroundColor: theme.cardSolid, justifyContent: 'center', alignItems: 'center', borderColor: theme.cardBorder, borderWidth: 1 }]}>
                                    <ActivityIndicator color={theme.accent} />
                                </View>
                            ) : weather ? (
                                <View style={[styles.weatherCard, { backgroundColor: wTheme.colors[0] }]}>
                                    <View style={styles.weatherDeco1} />
                                    <View style={styles.weatherDeco2} />
                                    <View style={styles.weatherTop}>
                                        <View style={{ flex: 1 }}>
                                            <Text style={styles.weatherCity}>{weather.name}</Text>
                                            <View style={styles.weatherBadge}>
                                                <Text style={styles.weatherBadgeText}>
                                                    {wTheme.emoji}  {weather.weather[0].description}
                                                </Text>
                                            </View>
                                        </View>
                                        <Text style={styles.weatherTempBig}>{Math.round(weather.main.temp)}°</Text>
                                    </View>
                                    <View style={styles.weatherStatsRow}>
                                        {[
                                            { icon: "water",       label: "Humidity",   value: `${weather.main.humidity}%` },
                                            { icon: "speedometer", label: "Wind",        value: `${weather.wind.speed} m/s` },
                                            { icon: "thermometer", label: "Feels like",  value: `${Math.round(weather.main.feels_like)}°C` },
                                            { icon: "sunny",       label: "Min/Max",     value: `${Math.round(weather.main.temp_min)}°/${Math.round(weather.main.temp_max)}°` },
                                        ].map((stat, i) => (
                                            <View key={i} style={styles.weatherStat}>
                                                <Ionicons name={stat.icon} size={13} color="rgba(255,255,255,0.75)" />
                                                <Text style={styles.weatherStatValue}>{stat.value}</Text>
                                                <Text style={styles.weatherStatLabel}>{stat.label}</Text>
                                            </View>
                                        ))}
                                    </View>
                                </View>
                            ) : null}
                        </View>

                        {/* ── Search bar ── */}
                        <View style={styles.searchSection}>
                            <Animated.View style={[
                                styles.searchBar,
                                {
                                    backgroundColor: theme.cardSolid,
                                    borderColor: searchFocusAnim.interpolate({
                                        inputRange: [0, 1],
                                        outputRange: [theme.inputBorder, theme.accent],
                                    }),
                                    elevation: searchFocusAnim.interpolate({ inputRange: [0, 1], outputRange: [4, 9] }),
                                }
                            ]}>
                                <Ionicons name="search" size={18} color={theme.accent} style={{ marginRight: 10 }} />
                                <TextInput
                                    value={searchText}
                                    onChangeText={handleSearchInput}
                                    onFocus={() => handleSearchFocus(true)}
                                    onBlur={() => handleSearchFocus(false)}
                                    placeholder="Search categories & sub-categories…"
                                    placeholderTextColor={theme.placeholder}
                                    style={[styles.searchInput, { color: theme.inputText }]}
                                    returnKeyType="search"
                                />
                                {searching && <ActivityIndicator size="small" color={theme.accent} style={{ marginLeft: 6 }} />}
                                {searchText.length > 0 && !searching && (
                                    <TouchableOpacity onPress={() => { setSearchText(""); setSuggestions([]); setShowSuggestion(false); }}>
                                        <Ionicons name="close-circle" size={18} color={theme.textMuted} />
                                    </TouchableOpacity>
                                )}
                            </Animated.View>

                            {showSuggestion && suggestions.length > 0 && (
                                <Animated.View style={[
                                    styles.suggestionBox,
                                    {
                                        backgroundColor: theme.cardSolid,
                                        borderColor: theme.cardBorder,
                                        opacity: suggestionAnim,
                                        transform: [{ translateY: suggestionAnim.interpolate({ inputRange: [0,1], outputRange: [-8, 0] }) }],
                                    }
                                ]}>
                                    {suggestions.map((item, index) => (
                                        <TouchableOpacity
                                            key={item.type + (item.id ?? index)}
                                            style={[
                                                styles.suggestionItem,
                                                { borderBottomColor: theme.divider },
                                                index === suggestions.length - 1 && { borderBottomWidth: 0 },
                                            ]}
                                            onPress={() => handleSuggestionPress(item)}
                                        >
                                            <View style={[
                                                styles.suggestionIcon,
                                                item.type === "category"
                                                    ? { backgroundColor: theme.accentGlow }
                                                    : { backgroundColor: isDark ? 'rgba(224,123,57,0.15)' : '#fdf0e8' },
                                            ]}>
                                                <Ionicons
                                                    name={item.type === "category" ? "grid-outline" : "leaf-outline"}
                                                    size={13}
                                                    color={item.type === "category" ? theme.accent : "#e07b39"}
                                                />
                                            </View>
                                            <View style={{ flex: 1 }}>
                                                <Text style={[styles.suggestionName, { color: theme.textPrimary }]}>{item.name}</Text>
                                                <Text style={[styles.suggestionType, { color: theme.textMuted }]}>
                                                    {item.type === "category" ? "Category" : "Sub-category"}
                                                </Text>
                                            </View>
                                            <Ionicons name="chevron-forward" size={14} color={theme.textMuted} />
                                        </TouchableOpacity>
                                    ))}
                                </Animated.View>
                            )}

                            {!searching && searchText.trim().length > 0 && suggestions.length === 0 && !showSuggestion && (
                                <View style={[styles.noResultBox, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder }]}>
                                    <Ionicons name="search-outline" size={20} color={theme.textMuted} />
                                    <Text style={[styles.noResultText, { color: theme.textMuted }]}>No results for "{searchText}"</Text>
                                </View>
                            )}
                        </View>

                        {/* ── Section header ── */}
                        <View style={styles.sectionHeader}>
                            <View>
                                <Text style={[styles.sectionTitle, { color: theme.textPrimary }]}>Browse Categories</Text>
                                <Text style={[styles.sectionSub, { color: theme.textSecondary }]}>Tap a category to explore</Text>
                            </View>
                            <View style={[styles.sectionAccent, { backgroundColor: theme.accent }]} />
                        </View>
                    </>
                }
                renderItem={({ item, index }) => (
                    <CategoryCard item={item} index={index} theme={theme} />
                )}
                ListFooterComponent={<View style={{ height: 110 }} />}
            />

            <Footer />
        </View>
    );
}

function CategoryCard({ item, index, theme }) {
    const fadeAnim  = useRef(new Animated.Value(0)).current;
    const scaleAnim = useRef(new Animated.Value(0.85)).current;
    const pressAnim = useRef(new Animated.Value(1)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(fadeAnim,  { toValue: 1, duration: 380, delay: index * 50, useNativeDriver: true }),
            Animated.spring(scaleAnim, { toValue: 1, delay: index * 50, useNativeDriver: true }),
        ]).start();
    }, []);

    return (
        <Animated.View style={{
            opacity: fadeAnim,
            transform: [{ scale: Animated.multiply(scaleAnim, pressAnim) }],
            width: (width - 48) / 3,
            margin: 6,
        }}>
            <TouchableOpacity
                onPressIn={() => Animated.spring(pressAnim, { toValue: 0.93, useNativeDriver: true }).start()}
                onPressOut={() => Animated.spring(pressAnim, { toValue: 1, useNativeDriver: true }).start()}
                onPress={() => router.push({ pathname: "/SubCategory", params: { categoryId: item.categoryId } })}
                activeOpacity={1}
            >
                <View style={[styles.catCard, {
                    backgroundColor: theme.cardSolid,
                    borderColor: theme.cardBorder,
                    borderWidth: 1,
                }]}>
                    <View style={styles.catImgWrap}>
                        <Image source={{ uri: item.imageLink }} style={styles.catImg} />
                        <View style={[styles.catImgOverlay, { backgroundColor: 'rgba(46,196,130,0.06)' }]} />
                    </View>
                    <Text style={[styles.catLabel, { color: theme.textPrimary }]} numberOfLines={2}>{item.categoryName}</Text>
                </View>
            </TouchableOpacity>
        </Animated.View>
    );
}

const styles = StyleSheet.create({
    root: { flex: 1 },

    bgOrb1: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(46,196,130,0.05)', top: -80, right: -80, zIndex: 0 },
    bgOrb2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(56,130,246,0.04)', top: height * 0.35, left: -60, zIndex: 0 },

    loadingScreen: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
    loadingText: { fontSize: 14, fontWeight: "600" },

    listContent: { paddingHorizontal: 12 },

    topBar: {
        flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
        paddingTop: 54, paddingBottom: 10, paddingHorizontal: 4,
    },
    greeting: { fontSize: 13, fontWeight: '500' },
    appName: { fontSize: 24, fontWeight: '900', letterSpacing: 1 },
    profileBtn: {
        width: 44, height: 44, borderRadius: 14,
        justifyContent: 'center', alignItems: 'center',
    },

    weatherSection: { paddingHorizontal: 4, paddingBottom: 14 },
    weatherCard: {
        borderRadius: 20, padding: 18, overflow: "hidden",
        shadowColor: "#000", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.25, shadowRadius: 14, elevation: 10,
        minHeight: 150,
    },
    weatherDeco1: { position: "absolute", width: 150, height: 150, borderRadius: 75, backgroundColor: "rgba(255,255,255,0.07)", right: -45, top: -45 },
    weatherDeco2: { position: "absolute", width: 90, height: 90, borderRadius: 45, backgroundColor: "rgba(255,255,255,0.05)", left: -25, bottom: -25 },
    weatherTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 },
    weatherCity: { fontSize: 22, fontWeight: "800", color: "#fff", letterSpacing: 0.3 },
    weatherBadge: { marginTop: 5, alignSelf: "flex-start", backgroundColor: "rgba(255,255,255,0.18)", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3 },
    weatherBadgeText: { color: "rgba(255,255,255,0.9)", fontSize: 12, fontWeight: "600", textTransform: "capitalize" },
    weatherTempBig: { fontSize: 56, fontWeight: "900", color: "#fff", lineHeight: 62 },
    weatherStatsRow: { flexDirection: "row", backgroundColor: "rgba(0,0,0,0.16)", borderRadius: 14, paddingVertical: 10, paddingHorizontal: 6 },
    weatherStat: { flex: 1, alignItems: "center", gap: 2 },
    weatherStatValue: { color: "#fff", fontSize: 11.5, fontWeight: "700" },
    weatherStatLabel: { color: "rgba(255,255,255,0.6)", fontSize: 9.5 },

    searchSection: { paddingHorizontal: 4, paddingBottom: 4, zIndex: 100 },
    searchBar: {
        flexDirection: "row", alignItems: "center",
        borderRadius: 16, borderWidth: 1.5, paddingHorizontal: 14, height: 50,
        shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 10,
    },
    searchInput: { flex: 1, fontSize: 14, fontWeight: "500" },

    suggestionBox: {
        borderRadius: 16, marginTop: 6, overflow: "hidden",
        shadowColor: "#000", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.15, shadowRadius: 16, elevation: 10,
        borderWidth: 1,
    },
    suggestionItem: {
        flexDirection: "row", alignItems: "center",
        paddingVertical: 11, paddingHorizontal: 14, borderBottomWidth: 1, gap: 10,
    },
    suggestionIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center" },
    suggestionName: { fontSize: 13.5, fontWeight: "700" },
    suggestionType: { fontSize: 11, fontWeight: "500", marginTop: 1 },

    noResultBox: {
        borderRadius: 14, marginTop: 6, padding: 14,
        flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1,
    },
    noResultText: { fontSize: 13, fontStyle: "italic" },

    sectionHeader: {
        flexDirection: "row", alignItems: "center", justifyContent: "space-between",
        paddingHorizontal: 4, paddingTop: 18, paddingBottom: 10,
    },
    sectionTitle: { fontSize: 22, fontWeight: "800", letterSpacing: 0.2 },
    sectionSub: { fontSize: 12.5, fontWeight: "500", marginTop: 2 },
    sectionAccent: { width: 8, height: 8, borderRadius: 4 },

    catCard: {
        borderRadius: 18, overflow: "hidden", alignItems: "center", paddingBottom: 10,
        shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.12, shadowRadius: 10, elevation: 5,
    },
    catImgWrap: {
        width: "100%", height: (width - 48) / 3,
        overflow: "hidden", borderTopLeftRadius: 18, borderTopRightRadius: 18,
    },
    catImg: { width: "100%", height: "100%", resizeMode: "cover" },
    catImgOverlay: { ...StyleSheet.absoluteFillObject },
    catLabel: {
        marginTop: 8, paddingHorizontal: 6,
        fontSize: 11.5, fontWeight: "700", textAlign: "center", lineHeight: 16,
    },
});