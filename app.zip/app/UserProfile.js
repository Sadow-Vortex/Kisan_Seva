// import React, { useEffect, useLayoutEffect, useState } from 'react';
// import {
//     View,
//     Text,
//     StyleSheet,
//     Image,
//     TouchableOpacity,
//     Alert,
//     ActivityIndicator,
//     Dimensions,
//     ScrollView
// } from 'react-native';
// import AsyncStorage from "@react-native-async-storage/async-storage";
// import { Ionicons } from "@expo/vector-icons";
// import { useNavigation } from "expo-router";
// import * as ImagePicker from 'expo-image-picker';
// import Footer from "./Footer";
// import { useRoute } from "@react-navigation/native";
// import axios from "axios";
//
// const { width } = Dimensions.get("window");
//
// export default function UserProfile() {
//
//     const navigation = useNavigation();
//     const [user, setUser] = useState(null);
//     const [loading, setLoading] = useState(true);
//     const [activeAdsCount, setActiveAdsCount] = useState(0);
//
//     const apiURL = `https://kisan-seva-user.onrender.com`;
//     const adsURL = "https://advertisment-jfil.onrender.com";
//
//
//     useLayoutEffect(() => {
//         navigation.setOptions({ headerShown: false });
//     }, [navigation]);
//
//     useEffect(() => {
//         const loadUser = async () => {
//             try {
//                 const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
//                 if (status !== 'granted') {
//                     Alert.alert('Permission Denied', 'Please allow access to your photos.');
//                 }
//
//                 const storedUser = await AsyncStorage.getItem('user');
//                 if (storedUser) {
//                     setUser(JSON.parse(storedUser));
//                 } else {
//                     navigation.reset({ index: 0, routes: [{ name: 'LoginScreen' }] });
//                 }
//             } catch (err) {
//                 console.error("Error loading user:");
//                 Alert.alert("Error", "Could not load user data.");
//             } finally {
//                 setLoading(false);
//             }
//         };
//
//         loadUser();
//     }, []);
//
//     useEffect(() => {
//         if (!user?.id) return;
//
//         axios
//             .get(`${adsURL}/adv/userID/${user.id}`)
//             .then(res => {
//
//                 const list = Array.isArray(res.data)
//                     ? res.data
//                     : res.data?.data || [];
//
//                 setActiveAdsCount(list.length);
//             })
//             .catch(err => {
//                 console.log("Failed to load ads count", err);
//                 setActiveAdsCount(0);
//             });
//
//     }, [user?.id]);
//
//
//     const updateImage = async (field) => {
//         try {
//             const result = await ImagePicker.launchImageLibraryAsync({
//                 mediaTypes: ImagePicker.MediaTypeOptions.Images,
//                 allowsEditing: true,
//                 aspect: field === 'coverPic' ? [4, 2] : [1, 1],
//                 quality: 0.6,
//             });
//
//             if (!result.canceled) {
//
//                 const imageUri = result.assets[0].uri;
//                 const filename = imageUri.split('/').pop();
//                 const match = /\.(\w+)$/.exec(filename ?? '');
//                 const type = match ? `image/${match[1]}` : `image`;
//
//                 const formData = new FormData();
//                 formData.append('file', {
//                     uri: imageUri,
//                     name: filename,
//                     type: type,
//                 });
//
//                 const uploadRes = await axios.post(`${apiURL}/api/users/upload`, formData, {
//                     headers: { 'Content-Type': 'multipart/form-data' },
//                 });
//
//                 const imageUrl = uploadRes.data?.filename;
//                 if (!imageUrl) throw new Error("Image upload failed");
//
//                 const updatedUser = { ...user, [field]: imageUrl };
//                 const updateRes = await axios.put(`${apiURL}/api/users/update/${user.id}`, updatedUser,  {
//                     headers: { 'Content-Type': 'application/json' },
//                 });
//
//                 const updatedUserData = updateRes.data?.data;
//
//                 if (updatedUserData) {
//                     const finalUser = Array.isArray(updatedUserData) ? updatedUserData[0] : updatedUserData;
//                     setUser(finalUser);
//                     await AsyncStorage.setItem('user', JSON.stringify(finalUser));
//                     Alert.alert('Success', `${field === 'profileImage' ? 'Profile' : 'Cover'} picture updated`);
//                 } else {
//                     throw new Error("User update response missing data");
//                 }
//             }
//
//         } catch (error) {
//             console.error("Upload error:", error);
//             Alert.alert('Error', 'Failed to update picture.');
//         }
//     };
//
//     const handleEdit = () => navigation.navigate('EditProfile', { userId: user?.id });
//     const handleAds = () => navigation.navigate('MyAds', { userId: user?.id });
//
//     const handleLogOut = async () => {
//         try {
//             await AsyncStorage.multiRemove(['user', 'isLogin', 'userId']);
//             Alert.alert('You have been logged out');
//             navigation.reset({ index: 0, routes: [{ name: 'LoginScreen' }] });
//         } catch (err) {
//             console.error(err);
//             Alert.alert('Error', 'Failed to log out');
//         }
//     };
//
//     if (loading || !user) {
//         return (
//             <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
//                 <ActivityIndicator size="large" />
//             </View>
//         );
//     }
//
//     return (
//         <View style={styles.container}>
//
//             <ScrollView
//                 showsVerticalScrollIndicator={false}
//                 contentContainerStyle={{ paddingBottom: 120 }}
//             >
//
//                 {/* Cover */}
//                 <View style={styles.coverWrapper}>
//
//                     {user.backImage ? (
//                         <Image  source={{ uri: `${apiURL}/uploads/${user.backImage}` }}
//                                 style={styles.cover} />
//                     ) : (
//                         <View style={styles.coverPlaceholder}>
//                             <Ionicons name="image-outline" size={40} color="#bbb" />
//                         </View>
//                     )}
//
//                     <TouchableOpacity
//                         style={styles.cameraCoverIcon}
//                         onPress={() => updateImage('backImage')}
//                     >
//                         <Ionicons name="camera" size={20} color="#fff" />
//                     </TouchableOpacity>
//
//                     {/* wave mask */}
//                     <View style={styles.waveMask} />
//
//                 </View>
//
//                 {/* Profile picture */}
//                 <View style={styles.profilePicContainer}>
//
//                     {user.profileImage ? (
//                         <Image  source={{ uri: `${apiURL}/uploads/${user.profileImage}` }}
//                                 style={styles.profilePic} />
//                     ) : (
//                         <Ionicons name="person" size={60} color="#999" />
//                     )}
//
//                     <TouchableOpacity
//                         style={styles.cameraProfileIcon}
//                         onPress={() => updateImage('profileImage')}
//                     >
//                         <Ionicons name="camera" size={16} color="#fff" />
//                     </TouchableOpacity>
//
//                 </View>
//
//                 {/* Info */}
//                 <View style={styles.infoBlock}>
//                     <Text style={styles.name}>
//                         {user.name || 'No Name'}
//                     </Text>
//
//                     <View style={styles.verifiedRow}>
//                         <Ionicons name="checkmark-circle" size={16} color="#6b7f3f" />
//                         <Text style={styles.verifiedText}>Verified Farmer</Text>
//                     </View>
//
//                     <View style={styles.locationRow}>
//                         <Ionicons name="location" size={16} color="#7c8557" />
//                         <Text style={styles.locationText}>
//                             Location not set
//                         </Text>
//                     </View>
//                 </View>
//
//                 {/* Top action buttons */}
//                 <View style={styles.topActionRow}>
//
//                     <TouchableOpacity
//                         style={styles.topActionCard}
//                         onPress={() =>
//                             navigation.navigate("Advertisement", {
//                                 userId: user?.id,
//                                 subCategoryId: null
//                             })
//                         }
//                     >
//                         <Ionicons name="add-circle-outline" size={22} color="#6b7f3f" />
//                         <Text style={styles.topActionText}>Post</Text>
//                     </TouchableOpacity>
//
//
//                     <TouchableOpacity style={styles.topActionCard}>
//                         <Ionicons name="chatbubble-ellipses" size={22} color="#6b7f3f" />
//                         <Text style={styles.topActionText}>Messages</Text>
//                     </TouchableOpacity>
//
//                 </View>
//
//                 {/* stats */}
//                 <View style={styles.statRow}>
//                     <View style={styles.statLine} />
//                     <Text style={styles.statText}>
//                         Active Ads : {activeAdsCount}
//                     </Text>
//                     <View style={styles.statLine} />
//                 </View>
//
//                 {/* menu cards */}
//                 <View style={styles.menuCard}>
//
//                     <TouchableOpacity style={styles.menuRow} onPress={handleAds}>
//                         <Ionicons name="megaphone" size={22} color="#6b7f3f" />
//                         <View style={styles.menuTextBlock}>
//                             <Text style={styles.menuTitle}>My Advertisements</Text>
//                             <Text style={styles.menuSub}>View, edit, and delete your ads.</Text>
//                         </View>
//                         <Ionicons name="chevron-forward" size={18} color="#9ca3af" />
//                     </TouchableOpacity>
//
//                     <TouchableOpacity style={styles.menuRow}>
//                         <Ionicons name="location" size={22} color="#6b7f3f" />
//                         <View style={styles.menuTextBlock}>
//                             <Text style={styles.menuTitle}>My Location</Text>
//                             <Text style={styles.menuSub}>Your pickup / farm location</Text>
//                         </View>
//                         <Ionicons name="chevron-forward" size={18} color="#9ca3af" />
//                     </TouchableOpacity>
//
//                     <TouchableOpacity style={styles.menuRow} onPress={handleEdit}>
//                         <Ionicons name="person" size={22} color="#6b7f3f" />
//                         <View style={styles.menuTextBlock}>
//                             <Text style={styles.menuTitle}>Account Info</Text>
//                             <Text style={styles.menuSub}>Name, phone, email</Text>
//                         </View>
//                         <Ionicons name="chevron-forward" size={18} color="#9ca3af" />
//                     </TouchableOpacity>
//
//                     <TouchableOpacity style={styles.menuRow}>
//                         <Ionicons name="help-circle" size={22} color="#6b7f3f" />
//                         <View style={styles.menuTextBlock}>
//                             <Text style={styles.menuTitle}>Help & Support</Text>
//                             <Text style={styles.menuSub}>Privacy & Terms</Text>
//                         </View>
//                         <Ionicons name="chevron-forward" size={18} color="#9ca3af" />
//                     </TouchableOpacity>
//
//                 </View>
//
//                 {/* logout */}
//                 <TouchableOpacity
//                     style={styles.logoutRow}
//                     onPress={handleLogOut}
//                 >
//                     <Ionicons name="power" size={20} color="#7c2d12" />
//                     <Text style={styles.logoutText}>Log out</Text>
//                 </TouchableOpacity>
//
//             </ScrollView>
//
//             <Footer />
//
//         </View>
//     );
// }
//
// const styles = StyleSheet.create({
//
//     container: {
//         flex: 1,
//         backgroundColor: "#FCEFE4"
//     },
//
//     coverWrapper: {
//         width: "100%",
//         height: 190,
//         overflow: "hidden"
//     },
//
//     cover: {
//         width: "100%",
//         height: 190
//     },
//
//     coverPlaceholder: {
//         width: "100%",
//         height: 190,
//         backgroundColor: "#e5e7eb",
//         justifyContent: "center",
//         alignItems: "center"
//     },
//
//     waveMask: {
//         position: "absolute",
//         bottom: -28,
//         width: width,
//         height: 56,
//         backgroundColor: "#FCEFE4",
//         borderTopLeftRadius: 60,
//         borderTopRightRadius: 60
//     },
//
//     cameraCoverIcon: {
//         position: 'absolute',
//         bottom: 18,
//         right: 18,
//         backgroundColor: '#0006',
//         padding: 8,
//         borderRadius: 18
//     },
//
//     profilePicContainer: {
//         alignSelf: "center",
//         marginTop: -60,
//         width: 110,
//         height: 110,
//         borderRadius: 55,
//         backgroundColor: "#fff",
//         justifyContent: "center",
//         alignItems: "center",
//         borderWidth: 4,
//         borderColor: "#fff",
//
//         shadowColor: "#000",
//         shadowOffset: { width: 0, height: 6 },
//         shadowOpacity: 0.18,
//         shadowRadius: 10,
//         elevation: 8
//     },
//
//     profilePic: {
//         width: 102,
//         height: 102,
//         borderRadius: 51
//     },
//
//     cameraProfileIcon: {
//         position: "absolute",
//         bottom: 4,
//         right: 4,
//         backgroundColor: "#0006",
//         padding: 5,
//         borderRadius: 14
//     },
//
//     infoBlock: {
//         marginTop: 10,
//         alignItems: "center"
//     },
//
//     name: {
//         fontSize: 22,
//         fontWeight: "800",
//         color: "#3f3f46"
//     },
//
//     verifiedRow: {
//         flexDirection: "row",
//         alignItems: "center",
//         marginTop: 6
//     },
//
//     verifiedText: {
//         marginLeft: 6,
//         fontSize: 13,
//         color: "#6b7f3f",
//         fontWeight: "600"
//     },
//
//     locationRow: {
//         flexDirection: "row",
//         alignItems: "center",
//         marginTop: 6
//     },
//
//     locationText: {
//         marginLeft: 6,
//         fontSize: 13,
//         color: "#7c8557"
//     },
//
//     topActionRow: {
//         flexDirection: "row",
//         gap: 12,
//         justifyContent: "center",
//         marginTop: 18
//     },
//
//     topActionCard: {
//         flexDirection: "row",
//         alignItems: "center",
//         gap: 8,
//         backgroundColor: "#ffffff",
//         paddingHorizontal: 16,
//         paddingVertical: 12,
//         borderRadius: 18,
//
//         shadowColor: "#000",
//         shadowOffset: { width: 0, height: 4 },
//         shadowOpacity: 0.12,
//         shadowRadius: 8,
//         elevation: 5
//     },
//
//     topActionText: {
//         fontWeight: "700",
//         color: "#374151"
//     },
//
//     statRow: {
//         flexDirection: "row",
//         alignItems: "center",
//         justifyContent: "center",
//         marginTop: 18,
//         marginBottom: 10
//     },
//
//     statLine: {
//         width: 60,
//         height: 1,
//         backgroundColor: "#e7d6c9"
//     },
//
//     statText: {
//         marginHorizontal: 10,
//         fontSize: 13,
//         color: "#6b7280",
//         fontWeight: "600"
//     },
//
//     menuCard: {
//         marginTop: 12,
//         marginHorizontal: 16,
//         backgroundColor: "#ffffff",
//         borderRadius: 22,
//         paddingVertical: 4,
//
//         shadowColor: "#000",
//         shadowOffset: { width: 0, height: 6 },
//         shadowOpacity: 0.12,
//         shadowRadius: 10,
//         elevation: 7
//     },
//
//     menuRow: {
//         flexDirection: "row",
//         alignItems: "center",
//         paddingHorizontal: 18,
//         paddingVertical: 14
//     },
//
//     menuTextBlock: {
//         flex: 1,
//         marginLeft: 12
//     },
//
//     menuTitle: {
//         fontSize: 14,
//         fontWeight: "800",
//         color: "#374151"
//     },
//
//     menuSub: {
//         fontSize: 12,
//         color: "#6b7280",
//         marginTop: 2
//     },
//
//     logoutRow: {
//         flexDirection: "row",
//         alignItems: "center",
//         gap: 8,
//         marginTop: 16,
//         marginHorizontal: 16,
//         backgroundColor: "#ffffff",
//         borderRadius: 18,
//         paddingVertical: 14,
//         paddingHorizontal: 18,
//
//         shadowColor: "#000",
//         shadowOffset: { width: 0, height: 4 },
//         shadowOpacity: 0.12,
//         shadowRadius: 8,
//         elevation: 5
//     },
//
//     logoutText: {
//         fontSize: 14,
//         fontWeight: "800",
//         color: "#7c2d12"
//     }
//
// });

import React, { useEffect, useLayoutEffect, useState, useRef } from 'react';
import {
    View, Text, StyleSheet, Image, TouchableOpacity, Alert,
    ActivityIndicator, Dimensions, ScrollView, StatusBar, Animated
} from 'react-native';
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "expo-router";
import * as ImagePicker from 'expo-image-picker';
import Footer from "./Footer";
import axios from "axios";
import { useTheme } from './Themecontext';

const { width } = Dimensions.get("window");

export default function UserProfile() {
    const navigation = useNavigation();
    const { theme, isDark, toggleTheme } = useTheme();
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [activeAdsCount, setActiveAdsCount] = useState(0);

    // Theme toggle animation
    const toggleAnim = useRef(new Animated.Value(isDark ? 1 : 0)).current;

    useEffect(() => {
        Animated.spring(toggleAnim, {
            toValue: isDark ? 1 : 0,
            friction: 6,
            useNativeDriver: true,
        }).start();
    }, [isDark]);

    const apiURL = `https://kisan-seva-user.onrender.com`;
    const adsURL = "https://advertisment-jfil.onrender.com";

    useLayoutEffect(() => { navigation.setOptions({ headerShown: false }); }, [navigation]);

    useEffect(() => {
        const loadUser = async () => {
            try {
                await ImagePicker.requestMediaLibraryPermissionsAsync();
                const storedUser = await AsyncStorage.getItem('user');
                if (storedUser) setUser(JSON.parse(storedUser));
                else navigation.reset({ index: 0, routes: [{ name: 'LoginScreen' }] });
            } catch { Alert.alert("Error", "Could not load user data."); }
            finally { setLoading(false); }
        };
        loadUser();
    }, []);

    useEffect(() => {
        if (!user?.id) return;
        axios.get(`${adsURL}/adv/userID/${user.id}`)
            .then(res => {
                const list = Array.isArray(res.data) ? res.data : res.data?.data || [];
                setActiveAdsCount(list.length);
            })
            .catch(() => setActiveAdsCount(0));
    }, [user?.id]);

    const updateImage = async (field) => {
        try {
            const result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: true,
                aspect: field === 'backImage' ? [4, 2] : [1, 1],
                quality: 0.6,
            });
            if (!result.canceled) {
                const imageUri = result.assets[0].uri;
                const filename = imageUri.split('/').pop();
                const match = /\.(\w+)$/.exec(filename ?? '');
                const type = match ? `image/${match[1]}` : `image`;
                const formData = new FormData();
                formData.append('file', { uri: imageUri, name: filename, type });
                const uploadRes = await axios.post(`${apiURL}/api/users/upload`, formData, {
                    headers: { 'Content-Type': 'multipart/form-data' },
                });
                const imageUrl = uploadRes.data?.filename;
                if (!imageUrl) throw new Error("Upload failed");
                const updatedUser = { ...user, [field]: imageUrl };
                const updateRes = await axios.put(`${apiURL}/api/users/update/${user.id}`, updatedUser, {
                    headers: { 'Content-Type': 'application/json' },
                });
                const updatedUserData = updateRes.data?.data;
                if (updatedUserData) {
                    const finalUser = Array.isArray(updatedUserData) ? updatedUserData[0] : updatedUserData;
                    setUser(finalUser);
                    await AsyncStorage.setItem('user', JSON.stringify(finalUser));
                    Alert.alert('Success', `${field === 'profileImage' ? 'Profile' : 'Cover'} picture updated`);
                }
            }
        } catch { Alert.alert('Error', 'Failed to update picture.'); }
    };

    const handleLogOut = async () => {
        try {
            await AsyncStorage.multiRemove(['user', 'isLogin', 'userId']);
            navigation.reset({ index: 0, routes: [{ name: 'LoginScreen' }] });
        } catch { Alert.alert('Error', 'Failed to log out'); }
    };

    if (loading || !user) {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.bg }}>
                <ActivityIndicator size="large" color={theme.accent} />
            </View>
        );
    }

    const menuItems = [
        {
            icon: 'megaphone', title: 'My Advertisements', sub: 'View, edit, and delete your ads',
            onPress: () => navigation.navigate('MyAds', { userId: user?.id }), badge: activeAdsCount,
        },
        { icon: 'location', title: 'My Location', sub: 'Your pickup / farm location', onPress: () => {} },
        {
            icon: 'person-circle', title: 'Account Info', sub: 'Name, phone, email',
            onPress: () => navigation.navigate('EditProfile', { userId: user?.id }),
        },
        { icon: 'help-circle', title: 'Help & Support', sub: 'Privacy & Terms', onPress: () => {} },
    ];

    // Theme toggle knob position
    const knobTranslate = toggleAnim.interpolate({ inputRange: [0, 1], outputRange: [2, 22] });

    return (
        <View style={[styles.container, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} />

            {/* Background orbs (dark mode only) */}
            {isDark && (
                <>
                    <View style={styles.orb1} />
                    <View style={styles.orb2} />
                </>
            )}

            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>

                {/* ── Cover ── */}
                <View style={styles.coverWrapper}>
                    {user.backImage ? (
                        <Image source={{ uri: `${apiURL}/uploads/${user.backImage}` }} style={styles.cover} />
                    ) : (
                        <View style={[styles.coverPlaceholder, { backgroundColor: isDark ? '#0d1f3a' : '#1a3d1a' }]}>
                            <View style={[styles.coverDeco1, { backgroundColor: isDark ? 'rgba(46,196,130,0.12)' : 'rgba(46,196,130,0.2)' }]} />
                            <View style={[styles.coverDeco2, { backgroundColor: isDark ? 'rgba(56,130,246,0.08)' : 'rgba(22,163,74,0.1)' }]} />
                        </View>
                    )}
                    <TouchableOpacity style={styles.coverCameraBtn} onPress={() => updateImage('backImage')}>
                        <Ionicons name="camera" size={16} color="#fff" />
                    </TouchableOpacity>
                    <View style={[styles.coverCurve, { backgroundColor: theme.bg }]} />
                </View>

                {/* ── Profile pic ── */}
                <View style={styles.profilePicOuter}>
                    <View style={[styles.profilePicRing, {
                        borderColor: isDark ? 'rgba(46,196,130,0.5)' : '#fff',
                        backgroundColor: theme.surface,
                    }]}>
                        {user.profileImage ? (
                            <Image source={{ uri: `${apiURL}/uploads/${user.profileImage}` }} style={styles.profilePic} />
                        ) : (
                            <View style={[styles.profilePicPlaceholder, { backgroundColor: theme.inputBg }]}>
                                <Ionicons name="person" size={48} color={theme.textMuted} />
                            </View>
                        )}
                    </View>
                    <TouchableOpacity style={[styles.profileCameraBtn, { backgroundColor: theme.accent }]} onPress={() => updateImage('profileImage')}>
                        <Ionicons name="camera" size={13} color={theme.accentDark} />
                    </TouchableOpacity>
                </View>

                {/* ── Name & info ── */}
                <View style={styles.infoBlock}>
                    <Text style={[styles.name, { color: theme.textPrimary }]}>{user.name || 'No Name'}</Text>
                    <View style={[styles.verifiedBadge, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}>
                        <Ionicons name="checkmark-circle" size={13} color={theme.accent} />
                        <Text style={[styles.verifiedText, { color: theme.accentText }]}>Verified Farmer</Text>
                    </View>
                    <Text style={[styles.contactText, { color: theme.textMuted }]}>{user.number || ''}</Text>
                </View>

                {/* ── Stats ── */}
                <View style={[styles.statsRow, {
                    backgroundColor: theme.cardSolid,
                    borderColor: theme.cardBorder,
                    borderWidth: 1,
                }]}>
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.textPrimary }]}>{activeAdsCount}</Text>
                        <Text style={[styles.statLabel, { color: theme.textMuted }]}>Active Ads</Text>
                    </View>
                    <View style={[styles.statDivider, { backgroundColor: theme.divider }]} />
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.textPrimary }]}>⭐ 4.8</Text>
                        <Text style={[styles.statLabel, { color: theme.textMuted }]}>Rating</Text>
                    </View>
                    <View style={[styles.statDivider, { backgroundColor: theme.divider }]} />
                    <View style={styles.statItem}>
                        <Text style={[styles.statValue, { color: theme.textPrimary }]}>🏅</Text>
                        <Text style={[styles.statLabel, { color: theme.textMuted }]}>Trusted</Text>
                    </View>
                </View>

                {/* ── Action buttons ── */}
                <View style={styles.actionRow}>
                    <TouchableOpacity
                        style={[styles.actionBtn, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}
                        onPress={() => navigation.navigate("Advertisement", { userId: user?.id, subCategoryId: null })}
                    >
                        <Ionicons name="add-circle" size={20} color={theme.accent} />
                        <Text style={[styles.actionBtnText, { color: theme.textPrimary }]}>Post Ad</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionBtn, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}>
                        <Ionicons name="chatbubble-ellipses" size={20} color={theme.accent} />
                        <Text style={[styles.actionBtnText, { color: theme.textPrimary }]}>Messages</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionBtn, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}>
                        <Ionicons name="share-social" size={20} color={theme.accent} />
                        <Text style={[styles.actionBtnText, { color: theme.textPrimary }]}>Share</Text>
                    </TouchableOpacity>
                </View>

                {/* ── Dark / Light mode toggle ── */}
                <View style={[styles.themeCard, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}>
                    <View style={styles.themeLeft}>
                        <View style={[styles.themeIconWrap, { backgroundColor: isDark ? 'rgba(46,196,130,0.15)' : 'rgba(250,204,21,0.15)' }]}>
                            <Ionicons
                                name={isDark ? 'moon' : 'sunny'}
                                size={20}
                                color={isDark ? '#7eeab4' : '#f59e0b'}
                            />
                        </View>
                        <View>
                            <Text style={[styles.themeTitle, { color: theme.textPrimary }]}>
                                {isDark ? 'Dark Mode' : 'Light Mode'}
                            </Text>
                            <Text style={[styles.themeSub, { color: theme.textSecondary }]}>
                                {isDark ? 'Switch to light theme' : 'Switch to dark theme'}
                            </Text>
                        </View>
                    </View>

                    {/* Custom animated toggle */}
                    <TouchableOpacity
                        onPress={toggleTheme}
                        activeOpacity={0.85}
                        style={[
                            styles.toggleTrack,
                            {
                                backgroundColor: isDark
                                    ? 'rgba(46,196,130,0.25)'
                                    : '#e5e7eb',
                                borderColor: isDark ? theme.accent : '#d1d5db',
                            }
                        ]}
                    >
                        <Animated.View style={[
                            styles.toggleKnob,
                            {
                                transform: [{ translateX: knobTranslate }],
                                backgroundColor: isDark ? theme.accent : '#9ca3af',
                            }
                        ]}>
                            <Ionicons
                                name={isDark ? 'moon' : 'sunny'}
                                size={10}
                                color={isDark ? '#0a1628' : '#fff'}
                            />
                        </Animated.View>
                    </TouchableOpacity>
                </View>

                {/* ── Menu ── */}
                <View style={[styles.menuCard, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}>
                    {menuItems.map((item, i) => (
                        <TouchableOpacity
                            key={i}
                            style={[styles.menuRow, i < menuItems.length - 1 && { borderBottomWidth: 1, borderBottomColor: theme.divider }]}
                            onPress={item.onPress}
                        >
                            <View style={[styles.menuIconWrap, { backgroundColor: theme.accentGlow }]}>
                                <Ionicons name={item.icon} size={20} color={theme.accent} />
                            </View>
                            <View style={styles.menuTextBlock}>
                                <Text style={[styles.menuTitle, { color: theme.textPrimary }]}>{item.title}</Text>
                                <Text style={[styles.menuSub, { color: theme.textSecondary }]}>{item.sub}</Text>
                            </View>
                            {item.badge > 0 && (
                                <View style={[styles.badge, { backgroundColor: theme.badgeBg }]}>
                                    <Text style={[styles.badgeText, { color: theme.accent }]}>{item.badge}</Text>
                                </View>
                            )}
                            <Ionicons name="chevron-forward" size={16} color={theme.textMuted} />
                        </TouchableOpacity>
                    ))}
                </View>

                {/* ── Logout ── */}
                <TouchableOpacity
                    style={[styles.logoutBtn, { backgroundColor: theme.dangerBg, borderColor: 'rgba(239,68,68,0.2)', borderWidth: 1 }]}
                    onPress={handleLogOut}
                >
                    <View style={styles.logoutInner}>
                        <Ionicons name="power" size={18} color={theme.danger} />
                        <Text style={[styles.logoutText, { color: theme.danger }]}>Log Out</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={16} color={theme.danger} style={{ opacity: 0.5 }} />
                </TouchableOpacity>

            </ScrollView>
            <Footer />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },

    orb1: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(46,196,130,0.05)', top: -100, right: -80, zIndex: 0 },
    orb2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(56,130,246,0.04)', top: 200, left: -60, zIndex: 0 },

    coverWrapper: { width: '100%', height: 200, position: 'relative' },
    cover: { width: '100%', height: 200 },
    coverPlaceholder: { width: '100%', height: 200, overflow: 'hidden' },
    coverDeco1: { position: 'absolute', width: 320, height: 320, borderRadius: 160, top: -100, right: -80 },
    coverDeco2: { position: 'absolute', width: 200, height: 200, borderRadius: 100, bottom: -60, left: 20 },
    coverCameraBtn: {
        position: 'absolute', bottom: 50, right: 16,
        backgroundColor: 'rgba(0,0,0,0.55)', padding: 9, borderRadius: 12,
    },
    coverCurve: {
        position: 'absolute', bottom: -20, left: 0, right: 0,
        height: 44, borderTopLeftRadius: 44, borderTopRightRadius: 44,
    },

    profilePicOuter: { alignSelf: 'center', marginTop: -50, width: 108, height: 108, position: 'relative' },
    profilePicRing: {
        width: 108, height: 108, borderRadius: 54,
        borderWidth: 3, overflow: 'hidden',
        shadowColor: '#2ec482', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 10,
    },
    profilePic: { width: '100%', height: '100%' },
    profilePicPlaceholder: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
    profileCameraBtn: {
        position: 'absolute', bottom: 2, right: 2,
        padding: 7, borderRadius: 12, borderWidth: 2, borderColor: 'rgba(255,255,255,0.2)',
    },

    infoBlock: { alignItems: 'center', marginTop: 12 },
    name: { fontSize: 22, fontWeight: '800', letterSpacing: 0.3 },
    verifiedBadge: {
        flexDirection: 'row', alignItems: 'center', gap: 5,
        paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, marginTop: 8,
    },
    verifiedText: { fontSize: 12, fontWeight: '700' },
    contactText: { marginTop: 6, fontSize: 13 },

    statsRow: {
        flexDirection: 'row', alignItems: 'center',
        marginHorizontal: 20, marginTop: 18,
        borderRadius: 20, paddingVertical: 14,
        shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.15, shadowRadius: 8, elevation: 4,
    },
    statItem: { flex: 1, alignItems: 'center' },
    statValue: { fontSize: 17, fontWeight: '800' },
    statLabel: { fontSize: 11, fontWeight: '500', marginTop: 2 },
    statDivider: { width: 1, height: 30 },

    actionRow: { flexDirection: 'row', gap: 10, justifyContent: 'center', marginTop: 14, marginHorizontal: 20 },
    actionBtn: {
        flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
        paddingVertical: 12, borderRadius: 16,
        shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6, elevation: 3,
    },
    actionBtnText: { fontWeight: '700', fontSize: 12 },

    // Theme toggle card
    themeCard: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        marginTop: 14, marginHorizontal: 20,
        paddingHorizontal: 16, paddingVertical: 14,
        borderRadius: 20,
        shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 6, elevation: 3,
    },
    themeLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    themeIconWrap: { width: 42, height: 42, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
    themeTitle: { fontSize: 14, fontWeight: '700' },
    themeSub: { fontSize: 12, marginTop: 2 },

    toggleTrack: {
        width: 48, height: 26, borderRadius: 13, borderWidth: 1,
        justifyContent: 'center',
    },
    toggleKnob: {
        width: 22, height: 22, borderRadius: 11,
        justifyContent: 'center', alignItems: 'center',
        shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 3,
    },

    menuCard: {
        marginTop: 14, marginHorizontal: 20, borderRadius: 20,
        shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 5,
    },
    menuRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 15 },
    menuIconWrap: { width: 40, height: 40, borderRadius: 13, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
    menuTextBlock: { flex: 1 },
    menuTitle: { fontSize: 14, fontWeight: '700' },
    menuSub: { fontSize: 12, marginTop: 2 },
    badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, marginRight: 8 },
    badgeText: { fontSize: 11, fontWeight: '700' },

    logoutBtn: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        marginTop: 12, marginHorizontal: 20,
        paddingVertical: 15, paddingHorizontal: 18, borderRadius: 18,
    },
    logoutInner: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    logoutText: { fontSize: 14, fontWeight: '700' },
});