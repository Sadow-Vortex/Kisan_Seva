import React, { useEffect, useState, useLayoutEffect } from 'react';
import {
    View, Text, StyleSheet, FlatList, Image, TouchableOpacity,
    Alert, ActivityIndicator, StatusBar, Animated
} from 'react-native';
import { useNavigation } from 'expo-router';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import Footer from './Footer';
import { useTheme } from './Themecontext';

export default function MyAds() {
    const navigation = useNavigation();
    const { userId } = useLocalSearchParams();
    const { theme, isDark } = useTheme();
    const [ads, setAds] = useState([]);
    const [loading, setLoading] = useState(true);

    const adsURL = 'https://advertisment-jfil.onrender.com';

    useLayoutEffect(() => { navigation.setOptions({ headerShown: false }); }, [navigation]);

    useEffect(() => { if (userId) fetchAds(); }, [userId]);

    const fetchAds = async () => {
        setLoading(true);
        try {
            const res = await axios.get(`${adsURL}/adv/userID/${userId}`);
            const list = Array.isArray(res.data) ? res.data : res.data?.data || [];
            setAds(list);
        } catch { setAds([]); }
        finally { setLoading(false); }
    };

    const handleDelete = (adId) => {
        Alert.alert('Delete Ad', 'Are you sure you want to delete this ad?', [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Delete', style: 'destructive',
                onPress: async () => {
                    try {
                        await axios.delete(`${adsURL}/adv/delete/${adId}`);
                        setAds(prev => prev.filter(a => a.adv_id !== adId));
                    } catch { Alert.alert('Error', 'Failed to delete ad'); }
                }
            }
        ]);
    };

    const renderAd = ({ item, index }) => (
        <Animated.View style={[styles.card, {
            backgroundColor: theme.cardSolid,
            borderColor: theme.cardBorder,
            borderWidth: 1,
        }]}>
            {item.imageLink ? (
                <Image source={{ uri: item.imageLink }} style={styles.image} />
            ) : (
                <View style={[styles.imagePlaceholder, { backgroundColor: isDark ? '#0d1f3a' : '#f0fdf4' }]}>
                    <Ionicons name="image-outline" size={40} color={theme.textMuted} />
                </View>
            )}

            <View style={[styles.activeBadge, { backgroundColor: theme.badgeBg }]}>
                <Ionicons name="checkmark-circle" size={10} color={theme.accent} />
                <Text style={[styles.activeBadgeText, { color: theme.accent }]}>Active</Text>
            </View>

            <View style={styles.details}>
                <Text style={[styles.title, { color: theme.textPrimary }]} numberOfLines={2}>{item.title}</Text>
                <Text style={[styles.price, { color: theme.accent }]}>
                    ₹{item.price ? Number(item.price).toLocaleString() : '—'}
                </Text>
                <View style={styles.locationRow}>
                    <Ionicons name="location-outline" size={13} color={theme.textMuted} />
                    <Text style={[styles.location, { color: theme.textSecondary }]} numberOfLines={1}>{item.location || 'Location not set'}</Text>
                </View>

                <View style={styles.buttonRow}>
                    <TouchableOpacity
                        style={[styles.button, styles.updateBtn, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}
                        onPress={() => navigation.navigate('UpdateAdvertisement', { adId: item.adv_id })}
                    >
                        <Ionicons name="create-outline" size={16} color={theme.accent} />
                        <Text style={[styles.btnText, { color: theme.accent }]}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.button, { backgroundColor: theme.dangerBg, borderColor: 'rgba(239,68,68,0.25)', borderWidth: 1 }]}
                        onPress={() => handleDelete(item.adv_id)}
                    >
                        <Ionicons name="trash-outline" size={16} color={theme.danger} />
                        <Text style={[styles.btnText, { color: theme.danger }]}>Delete</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </Animated.View>
    );

    return (
        <View style={[styles.container, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} />

            {/* Background orbs */}
            {isDark && (
                <>
                    <View style={[styles.orb1, { backgroundColor: 'rgba(46,196,130,0.05)' }]} />
                    <View style={[styles.orb2, { backgroundColor: 'rgba(56,130,246,0.04)' }]} />
                </>
            )}

            {/* Header */}
            <View style={[styles.header, { backgroundColor: theme.headerBg, borderBottomColor: theme.headerBorder }]}>
                <TouchableOpacity
                    onPress={() => navigation.goBack()}
                    style={[styles.backBtn, { backgroundColor: theme.backBtnBg }]}
                >
                    <Ionicons name="arrow-back" size={20} color={theme.backBtnIcon} />
                </TouchableOpacity>
                <View>
                    <Text style={[styles.headerTitle, { color: theme.textPrimary }]}>My Advertisements</Text>
                    <Text style={[styles.headerSub, { color: theme.textMuted }]}>
                        {ads.length} ad{ads.length !== 1 ? 's' : ''} posted
                    </Text>
                </View>
                <TouchableOpacity
                    style={[styles.addBtn, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}
                    onPress={() => navigation.navigate('Advertisement', { userId })}
                >
                    <Ionicons name="add" size={22} color={theme.accent} />
                </TouchableOpacity>
            </View>

            {loading ? (
                <View style={styles.centered}>
                    <ActivityIndicator size="large" color={theme.accent} />
                </View>
            ) : ads.length === 0 ? (
                <View style={styles.emptyState}>
                    <View style={[styles.emptyIconWrap, { backgroundColor: theme.accentGlow }]}>
                        <Text style={{ fontSize: 40 }}>🌾</Text>
                    </View>
                    <Text style={[styles.emptyTitle, { color: theme.textPrimary }]}>No ads yet</Text>
                    <Text style={[styles.emptySub, { color: theme.textSecondary }]}>
                        Start selling your produce by posting your first ad
                    </Text>
                    <TouchableOpacity
                        style={[styles.emptyBtn, { backgroundColor: theme.accent }]}
                        onPress={() => navigation.navigate('Advertisement', { userId })}
                    >
                        <Ionicons name="add-circle" size={18} color={theme.accentDark} />
                        <Text style={[styles.emptyBtnText, { color: theme.accentDark }]}>Post an Ad</Text>
                    </TouchableOpacity>
                </View>
            ) : (
                <FlatList
                    data={ads}
                    keyExtractor={(item) => item.adv_id.toString()}
                    renderItem={renderAd}
                    contentContainerStyle={styles.list}
                    refreshing={loading}
                    onRefresh={fetchAds}
                    showsVerticalScrollIndicator={false}
                />
            )}
            <Footer />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },

    orb1: { position: 'absolute', width: 250, height: 250, borderRadius: 125, top: -60, right: -60 },
    orb2: { position: 'absolute', width: 180, height: 180, borderRadius: 90, top: 300, left: -50 },

    header: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingTop: 54, paddingBottom: 14, paddingHorizontal: 16,
        borderBottomWidth: 1,
    },
    backBtn: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
    headerTitle: { fontSize: 18, fontWeight: '800', textAlign: 'center' },
    headerSub: { fontSize: 12, textAlign: 'center', marginTop: 2 },
    addBtn: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },

    centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

    list: { padding: 14, paddingBottom: 110 },

    card: {
        marginBottom: 14, borderRadius: 20, overflow: 'hidden',
        shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6,
    },
    image: { width: '100%', height: 170 },
    imagePlaceholder: { width: '100%', height: 170, justifyContent: 'center', alignItems: 'center' },

    activeBadge: {
        position: 'absolute', top: 12, left: 12,
        flexDirection: 'row', alignItems: 'center', gap: 4,
        paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
    },
    activeBadgeText: { fontSize: 10, fontWeight: '800' },

    details: { padding: 14 },
    title: { fontSize: 16, fontWeight: '800' },
    price: { fontSize: 17, fontWeight: '800', marginTop: 4 },
    locationRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
    location: { fontSize: 12, flex: 1 },

    buttonRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
    button: {
        flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
        gap: 6, paddingVertical: 10, borderRadius: 12,
    },
    updateBtn: {},
    btnText: { fontWeight: '700', fontSize: 13 },

    emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
    emptyIconWrap: { width: 90, height: 90, borderRadius: 28, justifyContent: 'center', alignItems: 'center', marginBottom: 10 },
    emptyTitle: { fontSize: 20, fontWeight: '800', marginTop: 6 },
    emptySub: { fontSize: 14, textAlign: 'center', marginTop: 8 },
    emptyBtn: {
        marginTop: 20, flexDirection: 'row', alignItems: 'center', gap: 8,
        paddingHorizontal: 28, paddingVertical: 12, borderRadius: 14,
    },
    emptyBtnText: { fontWeight: '700', fontSize: 14 },
});