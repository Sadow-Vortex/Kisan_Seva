// import React, { useEffect, useRef, useState } from 'react';
// import {
//     View, Text, TextInput, Button, Switch, StyleSheet,
//     ScrollView, Alert, TouchableOpacity, Image
// } from 'react-native';
// import axios from 'axios';
// import * as Location from 'expo-location';
// import RNPickerSelect from 'react-native-picker-select';
// import { useNavigation, useRoute } from '@react-navigation/native';
// import Icon from 'react-native-vector-icons/MaterialIcons';
// import * as ImagePicker from 'expo-image-picker';
//
// const UpdateAdvertisement = () => {
//     const scrollRef = useRef();
//     const navigation = useNavigation();
//     const route = useRoute();
//     const { adData } = route.params;
//
//     const url = "https://kisan-seva-subcategory.onrender.com";
//     const urll = "https://advertisment-jfil.onrender.com";
//     const [categories, setCategories] = useState([]);
//     const [subcategories, setSubcategories] = useState([]);
//
//     const [formData, setFormData] = useState({
//         adv_id: adData.adv_id,
//         advUserID: adData.advUserID,
//         adv_CategoryID: adData.adv_CategoryID?.toString(),
//         advSubCategoryID: adData.advSubCategoryID?.toString(),
//         adv_Title: adData.adv_Title || '',
//         adv_Description: adData.adv_Description || '',
//         adv_Unit: adData.adv_Unit?.toString() || '',
//         adv_Price: adData.adv_Price?.toString() || '',
//         adv_Address: adData.adv_Address || '',
//         adv_Image: adData.adv_Image || '',
//         adv_Status: adData.adv_Status,
//         adv_Latitude: adData.adv_Location?.latitude || 0,
//         adv_Longitude: adData.adv_Location?.longitude || 0
//     });
//
//     useEffect(() => {
//         axios.get(`${url}/category`)
//             .then(response => {
//                 setCategories(response.data?.data || []);
//             })
//             .catch(err => {
//                 console.error("Category fetch failed:");
//             });
//     }, []);
//
//     useEffect(() => {
//         if (formData.adv_CategoryID) {
//             axios.get(`${url}/subcategory/by-category/${formData.adv_CategoryID}`)
//                 .then(response => {
//                     setSubcategories(response.data?.data || []);
//                 })
//                 .catch(() => setSubcategories([]));
//         }
//     }, [formData.adv_CategoryID]);
//
//     const PickImage = async () => {
//         const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
//         if (!permission.granted) {
//             alert("Permission to access camera roll is required!");
//             return;
//         }
//
//         const result = await ImagePicker.launchImageLibraryAsync({
//             mediaTypes: ImagePicker.MediaTypeOptions.Images,
//             allowsEditing: true,
//             quality: 1,
//         });
//
//         if (!result.canceled) {
//             const uri = result.assets[0].uri;
//             setFormData(prev => ({ ...prev, adv_Image: uri }));
//         }
//     };
//
//     const handleLocationSelect = () => {
//         navigation.navigate('Map', {
//             onLocationSelected: async (location) => {
//                 const { latitude, longitude } = location;
//                 const geocode = await Location.reverseGeocodeAsync({ latitude, longitude });
//                 const address = geocode?.[0]
//                     ? [geocode[0].name, geocode[0].city, geocode[0].region, geocode[0].country].filter(Boolean).join(', ')
//                     : `Lat: ${latitude}, Lon: ${longitude}`;
//                 setFormData(prev => ({
//                     ...prev,
//                     adv_Latitude: latitude,
//                     adv_Longitude: longitude,
//                     adv_Address: address
//                 }));
//             }
//         });
//     };
//
//     const handleUpdate = () => {
//         if (!formData.adv_Title || !formData.adv_Unit || !formData.adv_Price) {
//             Alert.alert('Validation', 'Title, Unit, and Price are required.');
//             return;
//         }
//
//         const payload = {
//             adv_id: formData.adv_id,
//             advUserID: formData.advUserID,
//             adv_CategoryID: parseInt(formData.adv_CategoryID),
//             advSubCategoryID: parseInt(formData.advSubCategoryID),
//             adv_Title: formData.adv_Title,
//             adv_Description: formData.adv_Description,
//             adv_Unit: parseInt(formData.adv_Unit),
//             adv_Price: parseFloat(formData.adv_Price),
//             adv_Address: formData.adv_Address,
//             adv_Image: formData.adv_Image,
//             adv_Date: new Date().toISOString(),
//             adv_Status: formData.adv_Status,
//             adv_Location: {
//                 latitude: formData.adv_Latitude,
//                 longitude: formData.adv_Longitude
//             }
//         };
//
//         axios.put(`${urll}/adv/${formData.adv_id}`, payload)
//             .then(response => {
//                 if (response.data.status_code === 200) {
//                     Alert.alert('Success', 'Advertisement updated successfully.');
//                     navigation.goBack();
//                 } else {
//                     Alert.alert('Error', response.data.status_msg || 'Update failed.');
//                 }
//             })
//             .catch(err => {
//                 console.error('Update failed:', err);
//                 Alert.alert('Error', 'Something went wrong while updating.');
//             });
//     };
//
//
//     return (
//         <ScrollView ref={scrollRef} contentContainerStyle={styles.scrollContainer}>
//             <Text style={styles.label}>Title *</Text>
//             <TextInput
//                 style={styles.input}
//                 value={formData.adv_Title}
//                 onChangeText={text => setFormData(prev => ({ ...prev, adv_Title: text }))}
//             />
//
//             <Text style={styles.label}>Description</Text>
//             <TextInput
//                 style={[styles.input, { height: 80 }]}
//                 value={formData.adv_Description}
//                 multiline
//                 onChangeText={text => setFormData(prev => ({ ...prev, adv_Description: text }))}
//             />
//
//             <Text style={styles.label}>Unit *</Text>
//             <TextInput
//                 style={styles.input}
//                 value={formData.adv_Unit}
//                 keyboardType="numeric"
//                 onChangeText={text => setFormData(prev => ({ ...prev, adv_Unit: text }))}
//             />
//
//             <Text style={styles.label}>Price *</Text>
//             <TextInput
//                 style={styles.input}
//                 value={formData.adv_Price}
//                 keyboardType="numeric"
//                 onChangeText={text => setFormData(prev => ({ ...prev, adv_Price: text }))}
//             />
//
//             <Text style={styles.label}>Address</Text>
//             <View style={styles.inputWithIcon}>
//                 <TextInput
//                     style={styles.inputFlex}
//                     value={formData.adv_Address}
//                     onChangeText={text => setFormData(prev => ({ ...prev, adv_Address: text }))}
//                 />
//                 <TouchableOpacity onPress={handleLocationSelect}>
//                     <Icon name="location-on" size={24} color="#007bff" />
//                 </TouchableOpacity>
//             </View>
//
//             <Text style={styles.label}>Image</Text>
//             <TouchableOpacity onPress={PickImage} style={styles.button}>
//                 <Text style={{ color: 'blue' }}>Choose Image</Text>
//             </TouchableOpacity>
//             {formData.adv_Image && (
//                 <Image source={{ uri: formData.adv_Image }} style={{ width: 100, height: 100, marginTop: 10 }} />
//             )}
//
//             <View style={styles.switchContainer}>
//                 <Text>Status (Active)</Text>
//                 <Switch
//                     value={formData.adv_Status}
//                     onValueChange={val => setFormData(prev => ({ ...prev, adv_Status: val }))}
//                 />
//             </View>
//
//             <Button title="Update Advertisement" onPress={handleUpdate} />
//         </ScrollView>
//     );
// };
//
// const styles = StyleSheet.create({
//     scrollContainer: { padding: 20 },
//     input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, padding: 8, marginBottom: 15 },
//     label: { fontWeight: 'bold', marginBottom: 5 },
//     inputWithIcon: {
//         flexDirection: 'row', alignItems: 'center',
//         borderWidth: 1, borderColor: '#ccc', borderRadius: 5,
//         paddingHorizontal: 10, marginBottom: 15, backgroundColor: '#fff',
//         justifyContent: 'space-between'
//     },
//     inputFlex: { flex: 1, paddingVertical: 8, fontSize: 16 },
//     switchContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
//     button: { marginBottom: 15 }
// });
//
// export default UpdateAdvertisement;

import React, { useEffect, useRef, useState } from 'react';
import {
    View, Text, TextInput, Switch, StyleSheet,
    ScrollView, Alert, TouchableOpacity, Image, StatusBar
} from 'react-native';
import axios from 'axios';
import * as Location from 'expo-location';
import RNPickerSelect from 'react-native-picker-select';
import { useNavigation, useRoute } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';

const UpdateAdvertisement = () => {
    const scrollRef = useRef();
    const navigation = useNavigation();
    const route = useRoute();
    const { adData } = route.params;

    const url = "https://kisan-seva-subcategory.onrender.com";
    const urll = "https://advertisment-jfil.onrender.com";
    const [categories, setCategories] = useState([]);
    const [subcategories, setSubcategories] = useState([]);
    const [focusedField, setFocusedField] = useState(null);

    const [formData, setFormData] = useState({
        adv_id: adData.adv_id,
        advUserID: adData.advUserID,
        adv_CategoryID: adData.adv_CategoryID?.toString(),
        advSubCategoryID: adData.advSubCategoryID?.toString(),
        adv_Title: adData.adv_Title || '',
        adv_Description: adData.adv_Description || '',
        adv_Unit: adData.adv_Unit?.toString() || '',
        adv_Price: adData.adv_Price?.toString() || '',
        adv_Address: adData.adv_Address || '',
        adv_Image: adData.adv_Image || '',
        adv_Status: adData.adv_Status,
        adv_Latitude: adData.adv_Location?.latitude || 0,
        adv_Longitude: adData.adv_Location?.longitude || 0,
    });

    useEffect(() => {
        axios.get(`${url}/category`)
            .then(response => setCategories(response.data?.data || []))
            .catch(() => {});
    }, []);

    useEffect(() => {
        if (formData.adv_CategoryID) {
            axios.get(`${url}/subcategory/by-category/${formData.adv_CategoryID}`)
                .then(response => setSubcategories(response.data?.data || []))
                .catch(() => setSubcategories([]));
        }
    }, [formData.adv_CategoryID]);

    const PickImage = async () => {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) { alert("Permission required!"); return; }
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 1,
        });
        if (!result.canceled) {
            setFormData(prev => ({ ...prev, adv_Image: result.assets[0].uri }));
        }
    };

    const handleUpdate = () => {
        if (!formData.adv_Title || !formData.adv_Unit || !formData.adv_Price) {
            Alert.alert('Validation', 'Title, Unit, and Price are required.');
            return;
        }
        const payload = {
            adv_id: formData.adv_id, advUserID: formData.advUserID,
            adv_CategoryID: parseInt(formData.adv_CategoryID),
            advSubCategoryID: parseInt(formData.advSubCategoryID),
            adv_Title: formData.adv_Title, adv_Description: formData.adv_Description,
            adv_Unit: parseInt(formData.adv_Unit), adv_Price: parseFloat(formData.adv_Price),
            adv_Address: formData.adv_Address, adv_Image: formData.adv_Image,
            adv_Date: new Date().toISOString(), adv_Status: formData.adv_Status,
            adv_Location: { latitude: formData.adv_Latitude, longitude: formData.adv_Longitude }
        };
        axios.put(`${urll}/adv/${formData.adv_id}`, payload)
            .then(response => {
                if (response.data.status_code === 200) {
                    Alert.alert('Success', 'Advertisement updated successfully.');
                    navigation.goBack();
                } else {
                    Alert.alert('Error', response.data.status_msg || 'Update failed.');
                }
            })
            .catch(() => Alert.alert('Error', 'Something went wrong while updating.'));
    };

    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" />

            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
                    <Ionicons name="arrow-back" size={22} color="#1a2e1a" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Update Ad</Text>
                <View style={{ width: 40 }} />
            </View>

            <ScrollView ref={scrollRef} contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>

                {/* Category */}
                <View style={styles.sectionCard}>
                    <Text style={styles.sectionTitle}>📂 Category</Text>

                    <Text style={styles.label}>Category</Text>
                    <View style={styles.pickerWrap}>
                        <RNPickerSelect
                            onValueChange={value => setFormData(prev => ({ ...prev, adv_CategoryID: value }))}
                            items={categories.filter(c => c?.categoryId != null).map(c => ({
                                key: String(c.categoryId), label: String(c.categoryName ?? ''), value: c.categoryId
                            }))}
                            value={formData.adv_CategoryID}
                            placeholder={{ label: "Select Category", value: null }}
                            style={pickerStyles}
                        />
                    </View>

                    <Text style={styles.label}>Subcategory</Text>
                    <View style={styles.pickerWrap}>
                        <RNPickerSelect
                            onValueChange={value => setFormData(prev => ({ ...prev, advSubCategoryID: value }))}
                            items={subcategories.filter(s => s?.subCategoryId != null).map(s => ({
                                key: String(s.subCategoryId), label: String(s.subCategoryName ?? ''), value: s.subCategoryId
                            }))}
                            value={formData.advSubCategoryID}
                            placeholder={{ label: "Select Subcategory", value: null }}
                            style={pickerStyles}
                        />
                    </View>
                </View>

                {/* Details */}
                <View style={styles.sectionCard}>
                    <Text style={styles.sectionTitle}>📝 Ad Details</Text>

                    <Text style={styles.label}>Title *</Text>
                    <TextInput
                        style={[styles.input, focusedField === 'title' && styles.inputFocused]}
                        value={formData.adv_Title}
                        onChangeText={text => setFormData(prev => ({ ...prev, adv_Title: text }))}
                        placeholder="Ad title"
                        placeholderTextColor="#a0aec0"
                        onFocus={() => setFocusedField('title')}
                        onBlur={() => setFocusedField(null)}
                    />

                    <Text style={styles.label}>Description</Text>
                    <TextInput
                        style={[styles.input, styles.textArea, focusedField === 'desc' && styles.inputFocused]}
                        value={formData.adv_Description}
                        multiline
                        onChangeText={text => setFormData(prev => ({ ...prev, adv_Description: text }))}
                        placeholder="Description"
                        placeholderTextColor="#a0aec0"
                        onFocus={() => setFocusedField('desc')}
                        onBlur={() => setFocusedField(null)}
                    />

                    <View style={styles.row2}>
                        <View style={styles.col}>
                            <Text style={styles.label}>Unit *</Text>
                            <TextInput
                                style={[styles.input, focusedField === 'unit' && styles.inputFocused]}
                                value={formData.adv_Unit}
                                keyboardType="numeric"
                                onChangeText={text => setFormData(prev => ({ ...prev, adv_Unit: text }))}
                                placeholder="Qty"
                                placeholderTextColor="#a0aec0"
                                onFocus={() => setFocusedField('unit')}
                                onBlur={() => setFocusedField(null)}
                            />
                        </View>
                        <View style={styles.col}>
                            <Text style={styles.label}>Price *</Text>
                            <TextInput
                                style={[styles.input, focusedField === 'price' && styles.inputFocused]}
                                value={formData.adv_Price}
                                keyboardType="numeric"
                                onChangeText={text => setFormData(prev => ({ ...prev, adv_Price: text }))}
                                placeholder="₹ Price"
                                placeholderTextColor="#a0aec0"
                                onFocus={() => setFocusedField('price')}
                                onBlur={() => setFocusedField(null)}
                            />
                        </View>
                    </View>
                </View>

                {/* Location */}
                <View style={styles.sectionCard}>
                    <Text style={styles.sectionTitle}>📍 Location</Text>
                    <Text style={styles.label}>Address</Text>
                    <View style={styles.inputWithIcon}>
                        <TextInput
                            style={styles.inputFlex}
                            value={formData.adv_Address}
                            onChangeText={text => setFormData(prev => ({ ...prev, adv_Address: text }))}
                            placeholder="Enter address"
                            placeholderTextColor="#a0aec0"
                        />
                        <TouchableOpacity onPress={() => navigation.navigate('Map')} style={styles.mapBtn}>
                            <Ionicons name="location" size={20} color="#2ec482" />
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Image */}
                <View style={styles.sectionCard}>
                    <Text style={styles.sectionTitle}>🖼 Product Image</Text>
                    <TouchableOpacity onPress={PickImage} style={styles.imagePickerBtn}>
                        <Ionicons name="camera" size={22} color="#2d6a4f" />
                        <Text style={styles.imagePickerText}>Choose Image</Text>
                    </TouchableOpacity>
                    {formData.adv_Image ? (
                        <Image
                            source={{ uri: formData.adv_Image.startsWith('http') ? formData.adv_Image : `${urll}/uploads/${formData.adv_Image}` }}
                            style={styles.previewImage}
                        />
                    ) : null}
                </View>

                {/* Status */}
                <View style={styles.sectionCard}>
                    <View style={styles.switchRow}>
                        <View>
                            <Text style={styles.label}>Status</Text>
                            <Text style={{ fontSize: 12, color: '#6b7280' }}>Make ad visible to buyers</Text>
                        </View>
                        <Switch
                            value={formData.adv_Status}
                            onValueChange={val => setFormData(prev => ({ ...prev, adv_Status: val }))}
                            trackColor={{ false: '#e5e7eb', true: '#86efac' }}
                            thumbColor={formData.adv_Status ? '#16a34a' : '#9ca3af'}
                        />
                    </View>
                </View>

                <TouchableOpacity style={styles.submitBtn} onPress={handleUpdate}>
                    <Ionicons name="checkmark-circle" size={20} color="#fff" />
                    <Text style={styles.submitText}>Update Advertisement</Text>
                </TouchableOpacity>

            </ScrollView>
        </View>
    );
};

const pickerStyles = {
    inputIOS: { fontSize: 14, paddingVertical: 12, paddingHorizontal: 12, color: '#111827', paddingRight: 30 },
    inputAndroid: { fontSize: 14, paddingHorizontal: 12, paddingVertical: 10, color: '#111827', paddingRight: 30 },
    placeholder: { color: '#6b7280' },
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f1f5f1' },

    header: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingTop: 52, paddingBottom: 14, paddingHorizontal: 16,
        backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#e5f0e5',
        shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 4,
    },
    backBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#f0f7f0', justifyContent: 'center', alignItems: 'center' },
    headerTitle: { fontSize: 18, fontWeight: '800', color: '#1a2e1a' },

    scrollContainer: { padding: 14, paddingBottom: 40 },

    sectionCard: {
        backgroundColor: '#fff', borderRadius: 20, padding: 16, marginBottom: 14,
        shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.07, shadowRadius: 8, elevation: 4,
    },
    sectionTitle: { fontSize: 14, fontWeight: '800', color: '#1a2e1a', marginBottom: 14 },

    label: { fontSize: 13, fontWeight: '700', color: '#374151', marginBottom: 6 },

    pickerWrap: {
        borderWidth: 1.5, borderColor: '#e2e8f0', borderRadius: 14,
        paddingHorizontal: 4, backgroundColor: '#fafafa', marginBottom: 14,
    },

    input: {
        borderWidth: 1.5, borderColor: '#e2e8f0', borderRadius: 14,
        paddingHorizontal: 14, paddingVertical: 11, backgroundColor: '#fafafa',
        marginBottom: 14, fontSize: 14, color: '#111827',
    },
    inputFocused: { borderColor: '#16a34a', backgroundColor: '#f0fdf4' },
    textArea: { height: 88, textAlignVertical: 'top' },

    row2: { flexDirection: 'row', gap: 10 },
    col: { flex: 1 },

    inputWithIcon: {
        flexDirection: 'row', alignItems: 'center',
        borderWidth: 1.5, borderColor: '#e2e8f0', borderRadius: 14,
        paddingHorizontal: 14, marginBottom: 10, backgroundColor: '#fafafa',
    },
    inputFlex: { flex: 1, paddingVertical: 11, fontSize: 14, color: '#111827' },
    mapBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: '#f0fdf4', justifyContent: 'center', alignItems: 'center' },

    imagePickerBtn: {
        flexDirection: 'row', alignItems: 'center', gap: 10,
        borderWidth: 2, borderStyle: 'dashed', borderColor: '#86efac',
        borderRadius: 16, paddingVertical: 16, justifyContent: 'center',
        backgroundColor: '#f0fdf4', marginBottom: 12,
    },
    imagePickerText: { color: '#15803d', fontWeight: '700', fontSize: 14 },
    previewImage: { width: '100%', height: 180, borderRadius: 14 },

    switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },

    submitBtn: {
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
        backgroundColor: '#16a34a', paddingVertical: 16, borderRadius: 18, marginTop: 4,
        shadowColor: '#16a34a', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.35, shadowRadius: 14, elevation: 10,
    },
    submitText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});

export default UpdateAdvertisement;