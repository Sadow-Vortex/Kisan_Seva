import React, { useEffect, useLayoutEffect, useState, useCallback } from "react";
import {
    View, Text, StyleSheet, FlatList, Image, TouchableOpacity,
    ActivityIndicator, Dimensions, Modal, Alert, Linking,
    RefreshControl, StatusBar, ScrollView
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "expo-router";
import Footer from "./Footer";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { useTheme } from "./Themecontext";

const { width, height } = Dimensions.get("window");
const CARD_WIDTH = width / 2 - 20;

export default function FreshAd() {
    const navigation = useNavigation();
    const { theme, isDark } = useTheme();

    const [ads, setAds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [selectedAd, setSelectedAd] = useState(null);
    const [modalVisible, setModalVisible] = useState(false);

    const url = "https://advertisment-jfil.onrender.com";
    const userUrl = "https://kisan-seva-user.onrender.com";

    useLayoutEffect(() => { navigation.setOptions({ headerShown: false }); }, []);

    useEffect(() => { fetchFreshAds(); }, []);

    const fetchFreshAds = async () => {
        try {
            const res = await fetch(`${url}/adv`);
            const json = await res.json();
            const list = Array.isArray(json?.data) ? json.data : [];
            const freshOnly = list
                .filter(a => a.adv_Status === true)
                .sort((a, b) => new Date(b.adv_Date) - new Date(a.adv_Date));
            setAds(freshOnly);
        } catch (e) { console.error(e); }
        finally { setLoading(false); setRefreshing(false); }
    };

    const onRefresh = useCallback(() => { setRefreshing(true); fetchFreshAds(); }, []);

    const openModal = async (item) => {
        try {
            const res = await axios.get(`${userUrl}/api/users/${item.user_id}`);
            const farmer = res.data?.data || null;
            setSelectedAd({ ...item, farmer });
            const stored = await AsyncStorage.getItem('user');
            if (stored) {
                const user = JSON.parse(stored);
                await axios.put(`${url}/adv/view/${item.adv_id}`, { userId: user.id });
            }
        } catch { setSelectedAd(item); }
        setModalVisible(true);
    };

    const closeModal = () => { setModalVisible(false); setSelectedAd(null); };

    const openDialer = (number) => {
        if (!number) { Alert.alert("No number available"); return; }
        Linking.openURL(`tel:${number}`);
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
    };

    const renderItem = ({ item }) => {
        const imageUrl = item.adv_Image ? `${url}/uploads/${item.adv_Image}` : null;
        return (
            <TouchableOpacity
                style={[styles.card, {
                    backgroundColor: theme.cardSolid,
                    borderColor: theme.cardBorder,
                    borderWidth: 1,
                }]}
                activeOpacity={0.85}
                onPress={() => openModal(item)}
            >
                {imageUrl ? (
                    <Image source={{ uri: imageUrl }} style={styles.image} />
                ) : (
                    <View style={[styles.noImageBox, { backgroundColor: theme.inputBg }]}>
                        <Ionicons name="image-outline" size={34} color={theme.textMuted} />
                    </View>
                )}

                <View style={[styles.freshBadge, { backgroundColor: isDark ? 'rgba(56,130,246,0.15)' : '#eff6ff', borderColor: isDark ? 'rgba(96,165,250,0.3)' : '#bfdbfe', borderWidth: 1 }]}>
                    <Ionicons name="sparkles" size={10} color={isDark ? '#60a5fa' : '#3b82f6'} />
                    <Text style={[styles.freshBadgeText, { color: isDark ? '#60a5fa' : '#3b82f6' }]}>NEW</Text>
                </View>

                <View style={styles.cardBody}>
                    <Text numberOfLines={1} style={[styles.title, { color: theme.textPrimary }]}>{item.adv_Title}</Text>
                    <Text style={[styles.price, { color: theme.accent }]}>₹{item.adv_Price}</Text>
                    <View style={styles.bottomRow}>
                        <View style={styles.locationRow}>
                            <Ionicons name="location-outline" size={12} color={theme.textMuted} />
                            <Text numberOfLines={1} style={[styles.location, { color: theme.textSecondary }]}>
                                {item.adv_Address || "Location not set"}
                            </Text>
                        </View>
                        <Text style={[styles.dateText, { color: theme.textMuted }]}>{formatDate(item.adv_Date)}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    if (loading) {
        return (
            <View style={[styles.loader, { backgroundColor: theme.bg }]}>
                <ActivityIndicator size="large" color={theme.accent} />
            </View>
        );
    }

    return (
        <View style={[styles.container, { backgroundColor: theme.bg }]}>
            <StatusBar barStyle={theme.statusBar} />

            {isDark && (
                <>
                    <View style={styles.orb1} />
                    <View style={styles.orb2} />
                </>
            )}

            {/* Header */}
            <View style={[styles.header, { backgroundColor: theme.headerBg, borderBottomColor: theme.headerBorder }]}>
                {isDark && (
                    <>
                        <View style={styles.headerDeco1} />
                        <View style={styles.headerDeco2} />
                    </>
                )}
                <View style={styles.logoRow}>
                    <View style={[styles.logoWrap, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}>
                        <Image source={require("../assets/images/Logo.png")} style={styles.logo} />
                    </View>
                    <Text style={[styles.brand, { color: theme.textPrimary }]}>Kisan Seva</Text>
                </View>
                <Text style={[styles.subTitle, { color: theme.textMuted }]}>Latest listings from farmers</Text>
                <View style={styles.pageTitleRow}>
                    <View style={[styles.titleAccent, { backgroundColor: theme.accent }]} />
                    <Text style={[styles.pageTitle, { color: theme.textPrimary }]}>Fresh Ads</Text>
                </View>
            </View>

            {ads.length === 0 ? (
                <View style={styles.emptyState}>
                    <View style={[styles.emptyIconWrap, { backgroundColor: theme.accentGlow }]}>
                        <Text style={{ fontSize: 36 }}>🌱</Text>
                    </View>
                    <Text style={[styles.emptyTitle, { color: theme.textPrimary }]}>No fresh ads yet</Text>
                    <Text style={[styles.emptySub, { color: theme.textSecondary }]}>New listings will appear here</Text>
                </View>
            ) : (
                <FlatList
                    data={ads}
                    keyExtractor={(item) => item.adv_id.toString()}
                    renderItem={renderItem}
                    numColumns={2}
                    contentContainerStyle={styles.list}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh}
                            tintColor={theme.accent}
                            colors={[theme.accent]}
                        />
                    }
                />
            )}

            {/* Modal */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.modalBackground}>
                    <View style={[styles.modalSheet, { backgroundColor: theme.cardSolid, borderColor: theme.cardBorder, borderWidth: 1 }]}>
                        {selectedAd && (
                            <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
                                <View style={[styles.modalHandle, { backgroundColor: theme.divider }]} />

                                <TouchableOpacity onPress={closeModal} style={[styles.closeBtn, { backgroundColor: theme.backBtnBg }]}>
                                    <Ionicons name="close" size={20} color={theme.textPrimary} />
                                </TouchableOpacity>

                                <View style={styles.modalImageWrap}>
                                    {selectedAd.adv_Image ? (
                                        <Image source={{ uri: `${url}/uploads/${selectedAd.adv_Image}` }} style={styles.modalImage} />
                                    ) : (
                                        <View style={[styles.modalNoImage, { backgroundColor: theme.inputBg }]}>
                                            <Ionicons name="image-outline" size={40} color={theme.textMuted} />
                                        </View>
                                    )}
                                    <View style={[styles.freshTagOverlay, { backgroundColor: isDark ? 'rgba(56,130,246,0.15)' : '#eff6ff', borderColor: isDark ? 'rgba(96,165,250,0.3)' : '#bfdbfe', borderWidth: 1 }]}>
                                        <Ionicons name="sparkles" size={13} color={isDark ? '#60a5fa' : '#3b82f6'} />
                                        <Text style={[styles.freshTagText, { color: isDark ? '#60a5fa' : '#3b82f6' }]}>Fresh Listing</Text>
                                    </View>
                                </View>

                                <View style={styles.modalBody}>
                                    <Text style={[styles.modalTitle, { color: theme.textPrimary }]}>{selectedAd.adv_Title}</Text>
                                    <Text style={[styles.modalPrice, { color: theme.accent }]}>₹{selectedAd.adv_Price}</Text>
                                    <View style={styles.modalLocationRow}>
                                        <Ionicons name="location" size={15} color={theme.accent} />
                                        <Text style={[styles.modalLocation, { color: theme.textSecondary }]}>{selectedAd.adv_Address}</Text>
                                    </View>
                                    <Text style={[styles.modalDesc, { color: theme.textSecondary }]}>
                                        {selectedAd.adv_Description || "No description provided."}
                                    </Text>

                                    <View style={[styles.farmerCard, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}>
                                        <Text style={[styles.farmerHeader, { color: theme.textSecondary }]}>Farmer Information</Text>
                                        <View style={styles.farmerRow}>
                                            {selectedAd.farmer?.profileImage ? (
                                                <Image source={{ uri: `${userUrl}/uploads/${selectedAd.farmer.profileImage}` }} style={styles.farmerAvatar} />
                                            ) : (
                                                <View style={[styles.farmerAvatarPlaceholder, { backgroundColor: theme.inputBg }]}>
                                                    <Ionicons name="person" size={24} color={theme.textMuted} />
                                                </View>
                                            )}
                                            <View style={{ marginLeft: 12 }}>
                                                <Text style={[styles.farmerName, { color: theme.textPrimary }]}>{selectedAd.farmer?.name || "Unknown"}</Text>
                                                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 }}>
                                                    <Ionicons name="checkmark-circle" size={12} color={theme.accent} />
                                                    <Text style={[styles.farmerSub, { color: theme.accent }]}>Verified farmer</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </View>

                                <View style={styles.actionRow}>
                                    <TouchableOpacity
                                        style={[styles.actionBtn, { backgroundColor: theme.accent }]}
                                        onPress={() => openDialer(selectedAd.farmer?.number)}
                                    >
                                        <Ionicons name="call" size={18} color={theme.accentDark} />
                                        <Text style={[styles.actionText, { color: theme.accentDark }]}>Call</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        style={[styles.actionBtn, { backgroundColor: theme.accentGlow, borderColor: theme.accentBorder, borderWidth: 1 }]}
                                        onPress={() => Alert.alert("Chat", "Chat coming soon.")}
                                    >
                                        <Ionicons name="chatbubble-ellipses" size={18} color={theme.accent} />
                                        <Text style={[styles.actionText, { color: theme.accent }]}>Chat</Text>
                                    </TouchableOpacity>
                                </View>
                            </ScrollView>
                        )}
                    </View>
                </View>
            </Modal>

            <Footer />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },
    loader: { flex: 1, justifyContent: 'center', alignItems: 'center' },

    orb1: { position: 'absolute', width: 260, height: 260, borderRadius: 130, backgroundColor: 'rgba(46,196,130,0.05)', top: -60, right: -60 },
    orb2: { position: 'absolute', width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(56,130,246,0.04)', top: height * 0.4, left: -50 },

    header: { paddingTop: 54, paddingHorizontal: 20, paddingBottom: 18, borderBottomWidth: 1, overflow: 'hidden' },
    headerDeco1: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(46,196,130,0.06)', top: -60, right: -40 },
    headerDeco2: { position: 'absolute', width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(96,165,250,0.04)', top: 20, right: 60 },
    logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 6 },
    logoWrap: { width: 38, height: 38, borderRadius: 12, overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
    logo: { width: 44, height: 44, resizeMode: 'cover' },
    brand: { fontSize: 18, fontWeight: '800', letterSpacing: 0.5 },
    subTitle: { fontSize: 12, fontWeight: '500', marginBottom: 6 },
    pageTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    titleAccent: { width: 4, height: 24, borderRadius: 2 },
    pageTitle: { fontSize: 26, fontWeight: '900', letterSpacing: 0.3 },

    list: { padding: 12, paddingBottom: 110 },

    card: {
        width: CARD_WIDTH, margin: 6, borderRadius: 18, overflow: 'hidden',
        shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 10, elevation: 6,
    },
    image: { width: '100%', height: 140 },
    noImageBox: { width: '100%', height: 140, justifyContent: 'center', alignItems: 'center' },
    freshBadge: { position: 'absolute', top: 10, left: 10, flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
    freshBadgeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
    cardBody: { padding: 12 },
    title: { fontSize: 13, fontWeight: '800', marginBottom: 4 },
    price: { fontSize: 15, fontWeight: '800', marginBottom: 6 },
    bottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    locationRow: { flexDirection: 'row', alignItems: 'center', gap: 3, flex: 1 },
    location: { fontSize: 11, flex: 1 },
    dateText: { fontSize: 10, fontWeight: '600' },

    emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
    emptyIconWrap: { width: 80, height: 80, borderRadius: 24, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
    emptyTitle: { fontSize: 18, fontWeight: '800' },
    emptySub: { fontSize: 13, marginTop: 6, textAlign: 'center' },

    modalBackground: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
    modalSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: height * 0.88 },
    modalHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: 'center', marginTop: 12, marginBottom: 4 },
    closeBtn: { position: 'absolute', top: 16, right: 16, zIndex: 10, width: 36, height: 36, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
    modalImageWrap: { width: '100%', height: 220 },
    modalImage: { width: '100%', height: '100%' },
    modalNoImage: { width: '100%', height: '100%', justifyContent: 'center', alignItems: 'center' },
    freshTagOverlay: { position: 'absolute', bottom: 10, right: 14, flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
    freshTagText: { fontSize: 12, fontWeight: '700' },
    modalBody: { padding: 18 },
    modalTitle: { fontSize: 20, fontWeight: '800', marginBottom: 6 },
    modalPrice: { fontSize: 22, fontWeight: '900', marginBottom: 10 },
    modalLocationRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
    modalLocation: { fontSize: 13 },
    modalDesc: { fontSize: 13, lineHeight: 20, marginBottom: 14 },
    farmerCard: { borderRadius: 16, padding: 14, marginBottom: 4 },
    farmerHeader: { fontSize: 11, fontWeight: '700', letterSpacing: 0.5, textTransform: 'uppercase', marginBottom: 10 },
    farmerRow: { flexDirection: 'row', alignItems: 'center' },
    farmerAvatar: { width: 50, height: 50, borderRadius: 25 },
    farmerAvatarPlaceholder: { width: 50, height: 50, borderRadius: 25, justifyContent: 'center', alignItems: 'center' },
    farmerName: { fontSize: 15, fontWeight: '800' },
    farmerSub: { fontSize: 12, fontWeight: '600' },
    actionRow: { flexDirection: 'row', paddingHorizontal: 18, paddingBottom: 24, paddingTop: 4, gap: 12 },
    actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 16, gap: 8 },
    actionText: { fontWeight: '800', fontSize: 14 },
});